from __future__ import annotations

import uuid
from app.models.domain import AgentRunRequest, AgentRunResponse, Persona, PersonaFeedback, PainPointTheme, DesignGuardrail
from app.services.repository import list_personas, list_pain_points, list_guardrails, list_evidence_facts
from app.services.matching import find_relevant


def _as_persona(item: dict) -> Persona:
    return Persona(**{k: v for k, v in item.items() if k in Persona.model_fields})


def _as_pain_point(item: dict) -> PainPointTheme:
    return PainPointTheme(**{k: v for k, v in item.items() if k in PainPointTheme.model_fields})


def _as_guardrail(item: dict) -> DesignGuardrail:
    return DesignGuardrail(**{k: v for k, v in item.items() if k in DesignGuardrail.model_fields})


def select_personas(req: AgentRunRequest, pain_points: list[PainPointTheme]) -> list[Persona]:
    all_personas = [_as_persona(p) for p in list_personas()]
    if req.selected_persona_ids:
        selected = [p for p in all_personas if p.persona_id in req.selected_persona_ids]
        if selected:
            return selected

    terms = [req.product_area, req.journey, req.screen_name] + req.risk_categories
    for pp in pain_points:
        terms.extend(pp.related_personas)
        terms.extend(pp.risk_categories)

    selected = []
    for persona in all_personas:
        candidate = " ".join([persona.name, persona.description, " ".join(persona.tags), " ".join(persona.likely_questions), " ".join(persona.likely_friction_points)])
        if any(t.lower() in candidate.lower() for t in terms if t):
            selected.append(persona)

    return selected[:6] if selected else all_personas[:5]


def run_persona_agent(req: AgentRunRequest) -> AgentRunResponse:
    terms = [req.product_area, req.journey, req.screen_name, req.user_flow_context, req.screen_text] + req.risk_categories

    relevant_pp_items = find_relevant(list_pain_points(), terms, top_n=8)
    relevant_guardrail_items = find_relevant(list_guardrails(), terms, top_n=8)
    relevant_fact_items = find_relevant(list_evidence_facts(), terms, top_n=10)

    pain_points = [_as_pain_point(i) for i in relevant_pp_items]
    guardrails = [_as_guardrail(i) for i in relevant_guardrail_items]
    personas = select_personas(req, pain_points)

    feedback: list[PersonaFeedback] = []
    for persona in personas:
        related_pp = [
            pp for pp in pain_points
            if persona.persona_id in pp.related_personas
            or set(persona.tags).intersection(set(pp.risk_categories))
        ]
        evidence_summary = [
            f"{pp.theme}: {pp.description}" for pp in related_pp[:3]
        ]
        if not evidence_summary:
            evidence_summary = [f"Selected based on configured persona fit for {req.product_area} / {req.journey}."]

        likely_reaction = (
            f"{persona.name} may evaluate this screen by asking whether it helps them confidently decide: "
            f"Can I get this medication, under these coverage rules, at this pharmacy, for this cost, and what do I do next?"
        )

        design_implications = []
        for pp in related_pp[:3]:
            design_implications.extend(pp.design_guardrails[:2])
        design_implications.extend([g.title for g in guardrails[:2]])
        design_implications = list(dict.fromkeys(design_implications))[:5]

        severity = "High" if any(pp.severity in ("High", "Critical") for pp in related_pp) else "Medium"

        feedback.append(PersonaFeedback(
            persona_id=persona.persona_id,
            persona_name=persona.name,
            why_selected=f"Selected from persona library using product context and evidence-backed pain points for {req.product_area}.",
            evidence_summary=evidence_summary,
            likely_reaction=likely_reaction,
            likely_questions=persona.likely_questions,
            likely_friction_points=persona.likely_friction_points,
            design_implications=design_implications,
            severity=severity,
            human_review_flags=["UX", "Product"] + (["Compliance"] if any("cost" in x.lower() or "coverage" in x.lower() for x in req.risk_categories) else []),
        ))

    recs = []
    for g in guardrails:
        recs.append(f"{g.priority}: {g.title} — {g.description}")
    for pp in pain_points:
        for dg in pp.design_guardrails:
            recs.append(f"{pp.theme}: {dg}")
    recs = list(dict.fromkeys(recs))[:10]

    summary = (
        "Evidence-backed persona analysis completed. The strongest recurring pattern is decision confidence: "
        "members need coverage meaning, pricing transparency, pharmacy context, and next steps in one coherent path."
    )

    return AgentRunResponse(
        run_id=str(uuid.uuid4()),
        executive_summary=summary,
        product_area=req.product_area,
        journey=req.journey,
        screen_name=req.screen_name,
        evidence_used=relevant_fact_items,
        personas=personas,
        persona_feedback=feedback,
        relevant_pain_points=pain_points,
        relevant_guardrails=guardrails,
        prioritized_recommendations=recs,
        disclaimer="AI-generated simulated persona feedback. Use as research support only; not a replacement for moderated user research, accessibility, product, legal/compliance, or clinical review.",
    )
