from __future__ import annotations

from datetime import datetime, timezone
from typing import Literal
from pydantic import BaseModel, Field


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


Severity = Literal["Low", "Medium", "High", "Critical"]


class Persona(BaseModel):
    persona_id: str
    name: str
    description: str
    tags: list[str] = []
    attributes: dict[str, str] = {}
    goals: list[str] = []
    likely_questions: list[str] = []
    likely_friction_points: list[str] = []
    recruiting_value: str = ""
    evidence_ids: list[str] = []
    created_at: str = Field(default_factory=now_iso)
    updated_at: str = Field(default_factory=now_iso)


class EvidenceSource(BaseModel):
    source_id: str
    title: str
    source_type: str
    product_areas: list[str] = []
    journeys: list[str] = []
    source_date: str | None = None
    summary: str = ""
    key_takeaways: list[str] = []
    tags: list[str] = []
    created_at: str = Field(default_factory=now_iso)
    updated_at: str = Field(default_factory=now_iso)


class EvidenceFact(BaseModel):
    fact_id: str
    source_id: str
    fact_type: str = "research_insight"
    metric: str | None = None
    statement: str
    interpretation: str = ""
    product_area: str | None = None
    journey: str | None = None
    related_risk_categories: list[str] = []
    severity: Severity = "Medium"
    created_at: str = Field(default_factory=now_iso)


class PainPointTheme(BaseModel):
    pain_point_id: str
    theme: str
    description: str
    source_ids: list[str] = []
    product_areas: list[str] = []
    journeys: list[str] = []
    related_personas: list[str] = []
    risk_categories: list[str] = []
    severity: Severity = "Medium"
    design_guardrails: list[str] = []
    evidence_count: int = 0
    created_at: str = Field(default_factory=now_iso)
    updated_at: str = Field(default_factory=now_iso)


class DesignGuardrail(BaseModel):
    guardrail_id: str
    title: str
    description: str
    why_it_matters: str = ""
    applies_to_products: list[str] = []
    applies_to_risk_categories: list[str] = []
    review_questions: list[str] = []
    priority: Literal["Must-have", "Should-have", "Nice-to-have"] = "Should-have"
    source_ids: list[str] = []
    created_at: str = Field(default_factory=now_iso)
    updated_at: str = Field(default_factory=now_iso)


class AgentRunRequest(BaseModel):
    product_area: str
    journey: str
    screen_name: str
    user_flow_context: str
    screen_text: str = ""
    risk_categories: list[str] = []
    selected_persona_ids: list[str] = []
    use_llm: bool = False


class PersonaFeedback(BaseModel):
    persona_id: str
    persona_name: str
    why_selected: str
    evidence_summary: list[str] = []
    likely_reaction: str
    likely_questions: list[str] = []
    likely_friction_points: list[str] = []
    design_implications: list[str] = []
    severity: Severity = "Medium"
    human_review_flags: list[str] = ["UX"]


class AgentRunResponse(BaseModel):
    run_id: str
    executive_summary: str
    product_area: str
    journey: str
    screen_name: str
    evidence_used: list[dict] = []
    personas: list[Persona] = []
    persona_feedback: list[PersonaFeedback] = []
    relevant_pain_points: list[PainPointTheme] = []
    relevant_guardrails: list[DesignGuardrail] = []
    prioritized_recommendations: list[str] = []
    disclaimer: str
