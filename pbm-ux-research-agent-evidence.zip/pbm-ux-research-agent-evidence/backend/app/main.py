from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.routes_personas import router as personas_router
from app.api.routes_evidence import router as evidence_router
from app.api.routes_pain_points import router as pain_points_router
from app.api.routes_guardrails import router as guardrails_router
from app.api.routes_agent_runs import router as agent_runs_router
from app.core.settings import settings

app = FastAPI(title="PBM UX Research Agent", version="0.2.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(personas_router, prefix="/api/personas", tags=["Personas"])
app.include_router(evidence_router, prefix="/api/evidence", tags=["Evidence"])
app.include_router(pain_points_router, prefix="/api/pain-points", tags=["Pain Points"])
app.include_router(guardrails_router, prefix="/api/guardrails", tags=["Guardrails"])
app.include_router(agent_runs_router, prefix="/api/agent-runs", tags=["Agent Runs"])

@app.get("/health")
def health():
    return {"status": "ok"}
