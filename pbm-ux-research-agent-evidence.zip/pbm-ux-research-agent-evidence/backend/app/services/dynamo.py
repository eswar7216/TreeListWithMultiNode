from __future__ import annotations

import boto3
from boto3.dynamodb.conditions import Key, Attr
from app.core.settings import settings


def resource():
    return boto3.resource(
        "dynamodb",
        endpoint_url=settings.dynamodb_endpoint,
        region_name=settings.aws_region,
        aws_access_key_id=settings.aws_access_key_id,
        aws_secret_access_key=settings.aws_secret_access_key,
    )


def table():
    return resource().Table(settings.dynamodb_table)


def put_item(item: dict) -> dict:
    table().put_item(Item=item)
    return item


def get_item(pk: str, sk: str) -> dict | None:
    resp = table().get_item(Key={"PK": pk, "SK": sk})
    return resp.get("Item")


def query_pk(pk: str) -> list[dict]:
    resp = table().query(KeyConditionExpression=Key("PK").eq(pk))
    return resp.get("Items", [])


def scan_entity(entity_type: str) -> list[dict]:
    resp = table().scan(FilterExpression=Attr("entity_type").eq(entity_type))
    items = resp.get("Items", [])
    while "LastEvaluatedKey" in resp:
        resp = table().scan(
            FilterExpression=Attr("entity_type").eq(entity_type),
            ExclusiveStartKey=resp["LastEvaluatedKey"],
        )
        items.extend(resp.get("Items", []))
    return items


def delete_item(pk: str, sk: str) -> None:
    table().delete_item(Key={"PK": pk, "SK": sk})
