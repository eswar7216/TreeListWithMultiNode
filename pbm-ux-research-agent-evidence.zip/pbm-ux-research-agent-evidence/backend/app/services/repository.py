from __future__ import annotations

from app.models.domain import Persona, EvidenceSource, EvidenceFact, PainPointTheme, DesignGuardrail
from app.services import dynamo


def save_persona(persona: Persona) -> dict:
    item = persona.model_dump()
    item.update({"PK": f"PERSONA#{persona.persona_id}", "SK": "METADATA", "entity_type": "PERSONA"})
    return dynamo.put_item(item)


def list_personas() -> list[dict]:
    return dynamo.scan_entity("PERSONA")


def save_evidence_source(src: EvidenceSource) -> dict:
    item = src.model_dump()
    item.update({"PK": f"EVIDENCE_SOURCE#{src.source_id}", "SK": "METADATA", "entity_type": "EVIDENCE_SOURCE"})
    return dynamo.put_item(item)


def list_evidence_sources() -> list[dict]:
    return dynamo.scan_entity("EVIDENCE_SOURCE")


def save_evidence_fact(fact: EvidenceFact) -> dict:
    item = fact.model_dump()
    item.update({"PK": f"EVIDENCE_SOURCE#{fact.source_id}", "SK": f"FACT#{fact.fact_id}", "entity_type": "EVIDENCE_FACT"})
    return dynamo.put_item(item)


def list_evidence_facts() -> list[dict]:
    return dynamo.scan_entity("EVIDENCE_FACT")


def save_pain_point(pp: PainPointTheme) -> dict:
    item = pp.model_dump()
    item.update({"PK": f"PAIN_POINT#{pp.pain_point_id}", "SK": "VERSION#1", "entity_type": "PAIN_POINT_THEME"})
    return dynamo.put_item(item)


def list_pain_points() -> list[dict]:
    return dynamo.scan_entity("PAIN_POINT_THEME")


def save_guardrail(g: DesignGuardrail) -> dict:
    item = g.model_dump()
    item.update({"PK": f"DESIGN_GUARDRAIL#{g.guardrail_id}", "SK": "VERSION#1", "entity_type": "DESIGN_GUARDRAIL"})
    return dynamo.put_item(item)


def list_guardrails() -> list[dict]:
    return dynamo.scan_entity("DESIGN_GUARDRAIL")
