from __future__ import annotations

import httpx
from app.core.settings import settings


async def chat_json(system_prompt: str, user_prompt: str, max_tokens: int = 1800) -> dict:
    if not settings.litellm_configured:
        raise RuntimeError("LiteLLM is not configured")

    payload = {
        "model": settings.litellm_model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        "temperature": 0.1,
        "max_tokens": max_tokens,
        "response_format": {"type": "json_object"},
    }

    async with httpx.AsyncClient(timeout=60) as client:
        resp = await client.post(
            f"{settings.litellm_api_base.rstrip('/')}/chat/completions",
            headers={
                "Authorization": f"Bearer {settings.litellm_api_key}",
                "Content-Type": "application/json",
            },
            json=payload,
        )
        resp.raise_for_status()
        data = resp.json()
        import json
        return json.loads(data["choices"][0]["message"]["content"])
