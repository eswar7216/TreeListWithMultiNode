from __future__ import annotations

def norm(text: str) -> str:
    return (text or "").lower()

def score_text_match(query_terms: list[str], candidate_text: str) -> int:
    text = norm(candidate_text)
    return sum(1 for term in query_terms if norm(term) and norm(term) in text)

def find_relevant(items: list[dict], query_terms: list[str], top_n: int = 10) -> list[dict]:
    scored: list[tuple[int, dict]] = []
    for item in items:
        candidate = " ".join(str(v) for v in item.values() if isinstance(v, (str, list, dict)))
        score = score_text_match(query_terms, candidate)
        if score > 0:
            scored.append((score, item))
    scored.sort(key=lambda x: x[0], reverse=True)
    return [item for _, item in scored[:top_n]]
