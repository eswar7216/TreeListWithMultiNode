from fastapi import APIRouter
from app.models.domain import EvidenceSource, EvidenceFact
from app.services.repository import save_evidence_source, list_evidence_sources, save_evidence_fact, list_evidence_facts

router = APIRouter()

@router.get("/sources")
def get_sources():
    return list_evidence_sources()

@router.post("/sources")
def create_source(source: EvidenceSource):
    return save_evidence_source(source)

@router.get("/facts")
def get_facts():
    return list_evidence_facts()

@router.post("/facts")
def create_fact(fact: EvidenceFact):
    return save_evidence_fact(fact)
