from fastapi import APIRouter
from app.models.domain import AgentRunRequest
from app.agents.persona_agent import run_persona_agent

router = APIRouter()

@router.post("/persona")
def run_persona(req: AgentRunRequest):
    return run_persona_agent(req)
