from fastapi import APIRouter
from app.models.domain import DesignGuardrail
from app.services.repository import save_guardrail, list_guardrails

router = APIRouter()

@router.get("")
def get_guardrails():
    return list_guardrails()

@router.post("")
def create_guardrail(guardrail: DesignGuardrail):
    return save_guardrail(guardrail)
