from fastapi import APIRouter
from app.models.domain import Persona
from app.services.repository import save_persona, list_personas

router = APIRouter()

@router.get("")
def get_personas():
    return list_personas()

@router.post("")
def create_persona(persona: Persona):
    return save_persona(persona)
