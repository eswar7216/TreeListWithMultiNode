from fastapi import APIRouter
from app.models.domain import PainPointTheme
from app.services.repository import save_pain_point, list_pain_points

router = APIRouter()

@router.get("")
def get_pain_points():
    return list_pain_points()

@router.post("")
def create_pain_point(pain_point: PainPointTheme):
    return save_pain_point(pain_point)
