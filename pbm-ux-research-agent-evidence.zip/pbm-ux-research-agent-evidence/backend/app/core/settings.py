from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    aws_access_key_id: str = "dummy"
    aws_secret_access_key: str = "dummy"
    aws_region: str = "us-east-1"
    dynamodb_endpoint: str = "http://localhost:8002"
    dynamodb_table: str = "UXResearchAgent"

    litellm_api_base: str | None = None
    litellm_api_key: str | None = None
    litellm_model: str = "gpt-4o-mini"

    cors_origins: str = "http://localhost:5173"

    @property
    def cors_origins_list(self) -> list[str]:
        return [item.strip() for item in self.cors_origins.split(",") if item.strip()]

    @property
    def litellm_configured(self) -> bool:
        return bool(self.litellm_api_base and self.litellm_api_key)

    class Config:
        env_file = ".env"
        extra = "ignore"


settings = Settings()
