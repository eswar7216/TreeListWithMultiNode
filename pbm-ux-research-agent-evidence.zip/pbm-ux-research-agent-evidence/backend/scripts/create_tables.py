import boto3
from botocore.exceptions import ClientError
from app.core.settings import settings

dynamodb = boto3.client(
    "dynamodb",
    endpoint_url=settings.dynamodb_endpoint,
    region_name=settings.aws_region,
    aws_access_key_id=settings.aws_access_key_id,
    aws_secret_access_key=settings.aws_secret_access_key,
)

try:
    dynamodb.create_table(
        TableName=settings.dynamodb_table,
        KeySchema=[
            {"AttributeName": "PK", "KeyType": "HASH"},
            {"AttributeName": "SK", "KeyType": "RANGE"},
        ],
        AttributeDefinitions=[
            {"AttributeName": "PK", "AttributeType": "S"},
            {"AttributeName": "SK", "AttributeType": "S"},
        ],
        BillingMode="PAY_PER_REQUEST",
    )
    print(f"Created table {settings.dynamodb_table}")
except ClientError as exc:
    if exc.response["Error"]["Code"] == "ResourceInUseException":
        print(f"Table {settings.dynamodb_table} already exists")
    else:
        raise
