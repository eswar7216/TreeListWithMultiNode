from app.models.domain import Persona, EvidenceSource, EvidenceFact, PainPointTheme, DesignGuardrail
from app.services.repository import save_persona, save_evidence_source, save_evidence_fact, save_pain_point, save_guardrail

SOURCE_ID = "check_coverage_find_pharmacy_value_prop_2026"

personas = [
    Persona(
        persona_id="cost_sensitive_member",
        name="Cost-Sensitive Member",
        description="Member focused on prescription cost, price confidence, and avoiding surprise pharmacy charges.",
        tags=["cost", "price_transparency", "price_trust", "pharmacy_choice"],
        goals=["Know what I will pay", "Understand why costs differ", "Avoid surprise charges"],
        likely_questions=["Is this the final price?", "Why does price change by pharmacy?", "Is this retail, mail, 30-day, or 90-day?"],
        likely_friction_points=["Large price differences without explanation", "Cost unavailable states", "Unclear plan-stage impact"],
        recruiting_value="Validates price trust and cost logic comprehension."
    ),
    Persona(
        persona_id="coverage_confused_member",
        name="Coverage-Confused Member",
        description="Member who struggles to interpret coverage status, plan limitations, and not-covered paths.",
        tags=["coverage_clarity", "plan_limitations", "not_covered_recovery", "plain_language"],
        goals=["Know if medication is covered", "Understand plan rules", "Know what to do if not covered"],
        likely_questions=["Is this covered?", "What does this status mean?", "What are my covered alternatives?"],
        likely_friction_points=["Backend status labels", "No plain-language explanation", "Not covered without alternatives"],
        recruiting_value="Validates plain-language coverage meaning and recovery paths."
    ),
    Persona(
        persona_id="pharmacy_decision_member",
        name="Pharmacy Decision Member",
        description="Member trying to decide if a pharmacy is eligible, preferred, 90-day capable, and price-aligned.",
        tags=["pharmacy_eligibility", "network_clarity", "preferred_status", "90_day"],
        goals=["Confirm if pharmacy is eligible", "Compare pharmacy options", "Know if 90-day is available"],
        likely_questions=["Is this pharmacy preferred?", "Can I fill 90-day here?", "Will this pharmacy match the price?"],
        likely_friction_points=["Network tag confusion", "Map/list friction", "Default results not decision-ready"],
        recruiting_value="Validates Find a Pharmacy decision confidence."
    ),
    Persona(
        persona_id="caregiver",
        name="Caregiver Managing Prescriptions",
        description="Caregiver managing prescriptions and needing clear next steps for doctor, pharmacy, or support.",
        tags=["caregiver", "next_step_clarity", "download", "share", "doctor_handoff"],
        goals=["Understand what action to take", "Share details with doctor or family", "Avoid calls when self-service is enough"],
        likely_questions=["Who do I call?", "What do I tell the doctor?", "Can I save this?"],
        likely_friction_points=["No next-step module", "Disconnected coverage and pharmacy info", "Unclear printable/shareable summary"],
        recruiting_value="Validates next-step clarity and handoff behavior."
    ),
]

for p in personas:
    save_persona(p)

source = EvidenceSource(
    source_id=SOURCE_ID,
    title="Check Coverage & Find a Pharmacy Value Proposition",
    source_type="value_proposition_deck",
    product_areas=["Check Coverage", "Find a Pharmacy", "Unified Medication Decision"],
    journeys=["Medication coverage lookup", "Pharmacy selection", "Prescription cost comparison"],
    source_date="2026-06",
    summary="Research-backed strategy to unify coverage lookup and pharmacy selection into one decision-ready medication experience.",
    key_takeaways=[
        "Members are trying to answer: Can I get this medication, at this pharmacy, for this cost, and what do I do next?",
        "Check Coverage and Find a Pharmacy share root failures around decision confidence.",
        "A single medication decision page should unify coverage, pricing, pharmacy context, and next steps."
    ],
    tags=["coverage_clarity", "price_transparency", "pharmacy_choice", "next_step_clarity"]
)
save_evidence_source(source)

facts = [
    EvidenceFact(fact_id="unified_decision_question", source_id=SOURCE_ID, fact_type="research_principle", statement="Members need one confident decision path: medication, pharmacy, cost, and next step.", interpretation="Do not split coverage, pricing, and pharmacy decision-making across disconnected pages.", product_area="Unified Medication Decision", journey="Medication decision", related_risk_categories=["coverage_clarity", "price_transparency", "pharmacy_choice", "next_step_clarity"], severity="Critical"),
    EvidenceFact(fact_id="find_pharmacy_14_adoption", source_id=SOURCE_ID, fact_type="behavior_metric", metric="~14% logged-in users engage with Find a Pharmacy per session", statement="Find a Pharmacy has meaningful adoption.", interpretation="The journey matters, but usage breaks down before confident selection.", product_area="Find a Pharmacy", journey="Pharmacy selection", related_risk_categories=["pharmacy_eligibility"], severity="Medium"),
    EvidenceFact(fact_id="find_pharmacy_33_dropoff", source_id=SOURCE_ID, fact_type="behavior_metric", metric="~33% never reach Results from Search", statement="Search is front-loaded and fragile.", interpretation="Entry/defaults need simplification and resilient error handling.", product_area="Find a Pharmacy", journey="Pharmacy selection", related_risk_categories=["results_usability", "fallback_recovery"], severity="High"),
    EvidenceFact(fact_id="find_pharmacy_74_stall", source_id=SOURCE_ID, fact_type="behavior_metric", metric="74% stall at Results before confirming pharmacy", statement="Members stall at results instead of confidently choosing.", interpretation="Results must become a decision page, not a waypoint.", product_area="Find a Pharmacy", journey="Pharmacy selection", related_risk_categories=["pharmacy_eligibility", "network_clarity", "price_trust"], severity="High"),
    EvidenceFact(fact_id="filters_underused", source_id=SOURCE_ID, fact_type="behavior_metric", metric="~4.6% sessions apply filters; 90%+ rely on defaults", statement="Filter usage confirms: fix defaults, not filters.", interpretation="Default results quality drives most outcomes.", product_area="Find a Pharmacy", journey="Pharmacy selection", related_risk_categories=["results_usability"], severity="High"),
    EvidenceFact(fact_id="coverage_calls_48", source_id=SOURCE_ID, fact_type="call_insight", metric="48.5% calls touch coverage rules", statement="Coverage meaning and plan limitations must be surfaced immediately.", interpretation="Members need plain-language status meaning and action implications.", product_area="Check Coverage", journey="Coverage lookup", related_risk_categories=["coverage_clarity", "plan_limitations"], severity="Critical"),
    EvidenceFact(fact_id="cost_logic_calls_50", source_id=SOURCE_ID, fact_type="call_insight", metric="50.8% calls reference cost logic", statement="Pricing logic needs explanation.", interpretation="Explain 30/90-day, retail vs mail, deductible and plan-stage effects.", product_area="Check Coverage", journey="Prescription cost comparison", related_risk_categories=["price_transparency", "price_trust"], severity="Critical"),
    EvidenceFact(fact_id="not_covered_alternatives", source_id=SOURCE_ID, fact_type="call_insight", metric="9.7% calls seek alternatives", statement="Not-covered state must show alternatives or exception pathways.", interpretation="Never dead-end the member at not covered.", product_area="Check Coverage", journey="Not-covered recovery", related_risk_categories=["not_covered_recovery", "medication_alternatives"], severity="High"),
]
for f in facts:
    save_evidence_fact(f)

pain_points = [
    PainPointTheme(
        pain_point_id="decision_confidence_gap",
        theme="Decision confidence gap",
        description="Members are not simply looking for a price or a pharmacy. They need confidence that the medication is covered, available, priced accurately, and actionable.",
        source_ids=[SOURCE_ID],
        product_areas=["Check Coverage", "Find a Pharmacy", "Savings Advisor"],
        journeys=["Medication coverage lookup", "Pharmacy selection", "Medication savings recommendation"],
        related_personas=["cost_sensitive_member", "coverage_confused_member", "pharmacy_decision_member", "caregiver"],
        risk_categories=["coverage_clarity", "price_transparency", "pharmacy_eligibility", "next_step_clarity"],
        severity="Critical",
        design_guardrails=[
            "Unify coverage, pricing, pharmacy context, and next steps on one decision-ready page.",
            "Avoid forcing members to infer meaning from status labels alone.",
            "Show what action the member should take next."
        ],
        evidence_count=8,
    ),
    PainPointTheme(
        pain_point_id="price_trust_gap",
        theme="Price trust gap",
        description="Members lose confidence when price logic is opaque or when cost varies by pharmacy, supply, plan stage, retail, or mail without explanation.",
        source_ids=[SOURCE_ID],
        product_areas=["Check Coverage", "Find a Pharmacy", "Savings Advisor"],
        journeys=["Prescription cost comparison"],
        related_personas=["cost_sensitive_member", "coverage_confused_member"],
        risk_categories=["price_transparency", "price_trust", "cost_clarity"],
        severity="Critical",
        design_guardrails=[
            "Explain how 30/90-day, retail vs mail, deductible, plan stage, and pharmacy affect price.",
            "Clarify estimated versus final cost.",
            "Surface best-price callout with transparent pricing logic."
        ],
        evidence_count=4,
    ),
    PainPointTheme(
        pain_point_id="pharmacy_network_uncertainty",
        theme="Pharmacy network and eligibility uncertainty",
        description="Members need to confirm whether a pharmacy is in-network, preferred, eligible, 90-day capable, and price-aligned.",
        source_ids=[SOURCE_ID],
        product_areas=["Find a Pharmacy"],
        journeys=["Pharmacy selection"],
        related_personas=["pharmacy_decision_member", "cost_sensitive_member", "caregiver"],
        risk_categories=["pharmacy_eligibility", "network_clarity", "preferred_status", "90_day"],
        severity="High",
        design_guardrails=[
            "Show clear network tags: In-network, Preferred, Not preferred, Inactive.",
            "Make Results the decision page, not a waypoint.",
            "Offer pharmacy comparison earlier with search and compare."
        ],
        evidence_count=5,
    ),
    PainPointTheme(
        pain_point_id="not_covered_dead_end",
        theme="Not-covered dead end",
        description="When a drug is not covered, members need covered alternatives, generics, substitute guidance, or exception pathways immediately.",
        source_ids=[SOURCE_ID],
        product_areas=["Check Coverage"],
        journeys=["Not-covered recovery"],
        related_personas=["coverage_confused_member", "caregiver"],
        risk_categories=["not_covered_recovery", "medication_alternatives", "next_step_clarity"],
        severity="High",
        design_guardrails=[
            "Present covered alternatives immediately.",
            "Explain exception pathways in plain language.",
            "Do not leave members at a dead end."
        ],
        evidence_count=2,
    )
]
for pp in pain_points:
    save_pain_point(pp)

guardrails = [
    DesignGuardrail(
        guardrail_id="single_decision_ready_medication_page",
        title="Single decision-ready medication page",
        description="Surface coverage, pricing, pharmacy context, and next steps on one meaningful results page.",
        why_it_matters="Members are trying to decide with confidence, not navigate disconnected coverage, price, and pharmacy flows.",
        applies_to_products=["Check Coverage", "Find a Pharmacy", "Savings Advisor"],
        applies_to_risk_categories=["coverage_clarity", "price_transparency", "pharmacy_choice", "next_step_clarity"],
        review_questions=[
            "Does the screen answer whether the member can get this medication at this pharmacy for this cost?",
            "Are coverage, cost, pharmacy, and next steps visible together?",
            "Does the member know what to do next without calling support?"
        ],
        priority="Must-have",
        source_ids=[SOURCE_ID],
    ),
    DesignGuardrail(
        guardrail_id="surface_coverage_meaning_immediately",
        title="Surface coverage meaning and plan limitations immediately",
        description="Show coverage status with plain-language explanation of rules, plan limitations, and action implications.",
        why_it_matters="Nearly half of calls touch coverage rules; members need meaning, not backend labels.",
        applies_to_products=["Check Coverage", "Savings Advisor"],
        applies_to_risk_categories=["coverage_clarity", "plan_limitations", "plain_language"],
        review_questions=["Is the coverage status explained in plain language?", "Does it say what action is needed?"],
        priority="Must-have",
        source_ids=[SOURCE_ID],
    ),
    DesignGuardrail(
        guardrail_id="transparent_pricing_logic",
        title="Transparent pricing logic",
        description="Explain how 30/90-day supply, retail vs mail, deductible or plan stage, and pharmacy choice affect price.",
        why_it_matters="Pricing loses credibility when members cannot understand why the displayed cost differs from expectations.",
        applies_to_products=["Check Coverage", "Find a Pharmacy", "Savings Advisor"],
        applies_to_risk_categories=["price_transparency", "price_trust", "cost_clarity"],
        review_questions=["Is the cost type clear?", "Is the price period clear?", "Is estimated vs final cost clear?"],
        priority="Must-have",
        source_ids=[SOURCE_ID],
    ),
    DesignGuardrail(
        guardrail_id="how_to_get_medication_next_steps",
        title="How to get this medication next-step module",
        description="Do not stop at price and coverage. Tell members whether to fill at retail, switch to mail, request PA, or talk to their doctor.",
        why_it_matters="Members need action guidance after interpreting coverage and price.",
        applies_to_products=["Check Coverage", "Savings Advisor"],
        applies_to_risk_categories=["next_step_clarity", "doctor_involvement", "fulfillment"],
        review_questions=["Does the screen tell the member what to do next?", "Is doctor/pharmacy/support involvement clear?"],
        priority="Must-have",
        source_ids=[SOURCE_ID],
    ),
    DesignGuardrail(
        guardrail_id="not_covered_recovery_with_alternatives",
        title="Not-covered recovery with alternatives",
        description="Not-covered states must immediately show covered substitutes, generics, or exception pathways.",
        why_it_matters="Members call when not-covered states do not provide a recovery path.",
        applies_to_products=["Check Coverage"],
        applies_to_risk_categories=["not_covered_recovery", "medication_alternatives"],
        review_questions=["Does not-covered include alternatives?", "Does it avoid dead-ending the member?"],
        priority="Should-have",
        source_ids=[SOURCE_ID],
    ),
]
for g in guardrails:
    save_guardrail(g)

print("Seeded value proposition evidence, personas, pain points, and guardrails.")
