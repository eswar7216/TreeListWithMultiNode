import React, { useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import { UserRound, Library, AlertTriangle, ShieldCheck, PlayCircle, Database } from "lucide-react";
import "./styles.css";

const API = "http://localhost:8000/api";

async function apiGet(path) {
  const res = await fetch(`${API}${path}`);
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

async function apiPost(path, body) {
  const res = await fetch(`${API}${path}`, {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify(body)
  });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

function Field({label, children}) {
  return <label className="field"><span>{label}</span>{children}</label>;
}

function TextInput({value, onChange, placeholder}) {
  return <input value={value} onChange={e=>onChange(e.target.value)} placeholder={placeholder || ""} />;
}

function TextArea({value, onChange, placeholder, rows=4}) {
  return <textarea rows={rows} value={value} onChange={e=>onChange(e.target.value)} placeholder={placeholder || ""} />;
}

function TagsInput({value, onChange, placeholder}) {
  return <input value={value.join(", ")} onChange={e=>onChange(e.target.value.split(",").map(x=>x.trim()).filter(Boolean))} placeholder={placeholder || "comma separated"} />;
}

function Card({title, children, icon}) {
  return <section className="card">
    <div className="card-title">{icon}{title}</div>
    {children}
  </section>
}

function PersonaBuilder({refreshKey}) {
  const [persona, setPersona] = useState({
    persona_id: "coverage_confused_member",
    name: "Coverage-Confused Member",
    description: "Member who struggles to interpret coverage status, plan rules, and next steps.",
    tags: ["coverage_clarity", "plain_language", "next_step_clarity"],
    attributes: { digital_comfort: "medium", health_literacy: "low", cost_sensitivity: "medium", trust_level: "medium" },
    goals: ["Understand if medication is covered", "Know what action to take next"],
    likely_questions: ["Is this covered?", "What does this status mean?", "What should I do next?"],
    likely_friction_points: ["Backend status labels", "Not-covered dead ends", "Unclear plan limitations"],
    recruiting_value: "Validates plain-language coverage meaning and recovery paths."
  });
  const [status, setStatus] = useState("");

  async function save() {
    setStatus("Saving...");
    await apiPost("/personas", persona);
    setStatus("Saved persona.");
    refreshKey();
  }

  return <Card title="Persona Builder" icon={<UserRound size={20}/>}>
    <div className="grid2">
      <Field label="Persona ID"><TextInput value={persona.persona_id} onChange={v=>setPersona({...persona, persona_id:v})}/></Field>
      <Field label="Name"><TextInput value={persona.name} onChange={v=>setPersona({...persona, name:v})}/></Field>
    </div>
    <Field label="Description"><TextArea value={persona.description} onChange={v=>setPersona({...persona, description:v})}/></Field>
    <Field label="Tags"><TagsInput value={persona.tags} onChange={v=>setPersona({...persona, tags:v})}/></Field>
    <div className="grid4">
      {["digital_comfort","health_literacy","cost_sensitivity","trust_level"].map(k=>
        <Field key={k} label={k}>
          <select value={persona.attributes[k]} onChange={e=>setPersona({...persona, attributes:{...persona.attributes, [k]:e.target.value}})}>
            <option>low</option><option>medium</option><option>high</option>
          </select>
        </Field>
      )}
    </div>
    <Field label="Goals"><TagsInput value={persona.goals} onChange={v=>setPersona({...persona, goals:v})}/></Field>
    <Field label="Likely Questions"><TagsInput value={persona.likely_questions} onChange={v=>setPersona({...persona, likely_questions:v})}/></Field>
    <Field label="Likely Friction Points"><TagsInput value={persona.likely_friction_points} onChange={v=>setPersona({...persona, likely_friction_points:v})}/></Field>
    <Field label="Recruiting Value"><TextArea value={persona.recruiting_value} onChange={v=>setPersona({...persona, recruiting_value:v})} rows={2}/></Field>
    <button onClick={save}>Save Persona</button>
    <span className="status">{status}</span>
  </Card>
}

function EvidenceLibrary({refreshKey}) {
  const [src, setSrc] = useState({
    source_id: "member_feedback_coverage_cost_2026",
    title: "Member Feedback — Coverage and Cost Confusion",
    source_type: "feedback_summary",
    product_areas: ["Check Coverage", "Find a Pharmacy"],
    journeys: ["Medication coverage lookup", "Prescription cost comparison"],
    source_date: "2026-06",
    summary: "Aggregated de-identified feedback showing confusion around coverage status, pricing logic, pharmacy eligibility, and next steps.",
    key_takeaways: ["Members want one decision-ready answer", "Coverage and price need plain-language explanation"],
    tags: ["coverage_clarity", "price_transparency", "pharmacy_eligibility"]
  });
  const [fact, setFact] = useState({
    fact_id: "feedback_price_mismatch",
    source_id: "member_feedback_coverage_cost_2026",
    fact_type: "feedback_theme",
    metric: "",
    statement: "Members report that displayed price and pharmacy price can feel inconsistent.",
    interpretation: "Design should explain estimated price, plan-stage effects, pharmacy effects, and final adjudication dependency.",
    product_area: "Check Coverage",
    journey: "Prescription cost comparison",
    related_risk_categories: ["price_transparency", "price_trust", "cost_clarity"],
    severity: "High"
  });
  const [status, setStatus] = useState("");

  async function saveAll() {
    setStatus("Saving...");
    await apiPost("/evidence/sources", src);
    await apiPost("/evidence/facts", fact);
    setStatus("Saved evidence source and fact.");
    refreshKey();
  }

  return <Card title="Evidence Library" icon={<Library size={20}/>}>
    <h3>Evidence Source</h3>
    <div className="grid2">
      <Field label="Source ID"><TextInput value={src.source_id} onChange={v=>setSrc({...src, source_id:v})}/></Field>
      <Field label="Title"><TextInput value={src.title} onChange={v=>setSrc({...src, title:v})}/></Field>
    </div>
    <div className="grid3">
      <Field label="Source Type"><TextInput value={src.source_type} onChange={v=>setSrc({...src, source_type:v})}/></Field>
      <Field label="Date"><TextInput value={src.source_date} onChange={v=>setSrc({...src, source_date:v})}/></Field>
      <Field label="Tags"><TagsInput value={src.tags} onChange={v=>setSrc({...src, tags:v})}/></Field>
    </div>
    <Field label="Product Areas"><TagsInput value={src.product_areas} onChange={v=>setSrc({...src, product_areas:v})}/></Field>
    <Field label="Journeys"><TagsInput value={src.journeys} onChange={v=>setSrc({...src, journeys:v})}/></Field>
    <Field label="Summary"><TextArea value={src.summary} onChange={v=>setSrc({...src, summary:v})}/></Field>
    <Field label="Key Takeaways"><TagsInput value={src.key_takeaways} onChange={v=>setSrc({...src, key_takeaways:v})}/></Field>

    <h3>Evidence Fact</h3>
    <div className="grid2">
      <Field label="Fact ID"><TextInput value={fact.fact_id} onChange={v=>setFact({...fact, fact_id:v})}/></Field>
      <Field label="Severity">
        <select value={fact.severity} onChange={e=>setFact({...fact, severity:e.target.value})}>
          <option>Low</option><option>Medium</option><option>High</option><option>Critical</option>
        </select>
      </Field>
    </div>
    <Field label="Statement"><TextArea value={fact.statement} onChange={v=>setFact({...fact, statement:v})}/></Field>
    <Field label="Interpretation"><TextArea value={fact.interpretation} onChange={v=>setFact({...fact, interpretation:v})}/></Field>
    <Field label="Risk Categories"><TagsInput value={fact.related_risk_categories} onChange={v=>setFact({...fact, related_risk_categories:v})}/></Field>
    <button onClick={saveAll}>Save Evidence</button>
    <span className="status">{status}</span>
  </Card>
}

function PainPointBuilder({refreshKey}) {
  const [pp, setPp] = useState({
    pain_point_id: "decision_confidence_gap",
    theme: "Decision confidence gap",
    description: "Members need confidence that medication is covered, available at pharmacy, priced accurately, and actionable.",
    source_ids: ["check_coverage_find_pharmacy_value_prop_2026"],
    product_areas: ["Check Coverage", "Find a Pharmacy", "Savings Advisor"],
    journeys: ["Medication coverage lookup", "Pharmacy selection"],
    related_personas: ["cost_sensitive_member", "coverage_confused_member", "pharmacy_decision_member"],
    risk_categories: ["coverage_clarity", "price_transparency", "pharmacy_eligibility", "next_step_clarity"],
    severity: "Critical",
    design_guardrails: ["Unify coverage, pricing, pharmacy context, and next steps on one decision-ready page."],
    evidence_count: 8
  });
  const [status, setStatus] = useState("");
  async function save(){ setStatus("Saving..."); await apiPost("/pain-points", pp); setStatus("Saved pain point."); refreshKey(); }
  return <Card title="Pain Point Theme Builder" icon={<AlertTriangle size={20}/>}>
    <div className="grid2">
      <Field label="Pain Point ID"><TextInput value={pp.pain_point_id} onChange={v=>setPp({...pp, pain_point_id:v})}/></Field>
      <Field label="Theme"><TextInput value={pp.theme} onChange={v=>setPp({...pp, theme:v})}/></Field>
    </div>
    <Field label="Description"><TextArea value={pp.description} onChange={v=>setPp({...pp, description:v})}/></Field>
    <div className="grid2">
      <Field label="Severity"><select value={pp.severity} onChange={e=>setPp({...pp, severity:e.target.value})}><option>Low</option><option>Medium</option><option>High</option><option>Critical</option></select></Field>
      <Field label="Evidence Count"><input type="number" value={pp.evidence_count} onChange={e=>setPp({...pp, evidence_count:Number(e.target.value)})}/></Field>
    </div>
    <Field label="Product Areas"><TagsInput value={pp.product_areas} onChange={v=>setPp({...pp, product_areas:v})}/></Field>
    <Field label="Risk Categories"><TagsInput value={pp.risk_categories} onChange={v=>setPp({...pp, risk_categories:v})}/></Field>
    <Field label="Related Personas"><TagsInput value={pp.related_personas} onChange={v=>setPp({...pp, related_personas:v})}/></Field>
    <Field label="Design Guardrails"><TagsInput value={pp.design_guardrails} onChange={v=>setPp({...pp, design_guardrails:v})}/></Field>
    <button onClick={save}>Save Pain Point</button><span className="status">{status}</span>
  </Card>
}

function GuardrailBuilder({refreshKey}) {
  const [g, setG] = useState({
    guardrail_id: "single_decision_ready_medication_page",
    title: "Single decision-ready medication page",
    description: "Surface coverage, pricing, pharmacy context, and next steps on one meaningful results page.",
    why_it_matters: "Members need decision confidence, not disconnected coverage, price, and pharmacy views.",
    applies_to_products: ["Check Coverage", "Find a Pharmacy", "Savings Advisor"],
    applies_to_risk_categories: ["coverage_clarity", "price_transparency", "pharmacy_choice", "next_step_clarity"],
    review_questions: ["Does the screen answer coverage, cost, pharmacy, and next action?", "Can the member proceed without calling support?"],
    priority: "Must-have",
    source_ids: ["check_coverage_find_pharmacy_value_prop_2026"]
  });
  const [status, setStatus] = useState("");
  async function save(){ setStatus("Saving..."); await apiPost("/guardrails", g); setStatus("Saved guardrail."); refreshKey(); }
  return <Card title="Design Guardrail Builder" icon={<ShieldCheck size={20}/>}>
    <div className="grid2">
      <Field label="Guardrail ID"><TextInput value={g.guardrail_id} onChange={v=>setG({...g, guardrail_id:v})}/></Field>
      <Field label="Title"><TextInput value={g.title} onChange={v=>setG({...g, title:v})}/></Field>
    </div>
    <Field label="Description"><TextArea value={g.description} onChange={v=>setG({...g, description:v})}/></Field>
    <Field label="Why It Matters"><TextArea value={g.why_it_matters} onChange={v=>setG({...g, why_it_matters:v})}/></Field>
    <Field label="Priority"><select value={g.priority} onChange={e=>setG({...g, priority:e.target.value})}><option>Must-have</option><option>Should-have</option><option>Nice-to-have</option></select></Field>
    <Field label="Applies to Products"><TagsInput value={g.applies_to_products} onChange={v=>setG({...g, applies_to_products:v})}/></Field>
    <Field label="Risk Categories"><TagsInput value={g.applies_to_risk_categories} onChange={v=>setG({...g, applies_to_risk_categories:v})}/></Field>
    <Field label="Review Questions"><TagsInput value={g.review_questions} onChange={v=>setG({...g, review_questions:v})}/></Field>
    <button onClick={save}>Save Guardrail</button><span className="status">{status}</span>
  </Card>
}

function AgentRun() {
  const [req, setReq] = useState({
    product_area: "Check Coverage",
    journey: "Medication coverage lookup",
    screen_name: "Decision-ready Results Page",
    user_flow_context: "Member searches a medication and needs to understand coverage, price, pharmacy options, and what to do next.",
    screen_text: "Coverage status, plan rules, best price, pharmacy comparison, covered alternatives, next steps",
    risk_categories: ["coverage_clarity", "price_transparency", "pharmacy_choice", "next_step_clarity"],
    selected_persona_ids: [],
    use_llm: false
  });
  const [result, setResult] = useState(null);
  const [status, setStatus] = useState("");

  async function run() {
    setStatus("Running evidence-backed Persona Agent...");
    const res = await apiPost("/agent-runs/persona", req);
    setResult(res);
    setStatus("Completed.");
  }

  return <Card title="Run Evidence-Backed Persona Agent" icon={<PlayCircle size={20}/>}>
    <div className="grid2">
      <Field label="Product Area"><TextInput value={req.product_area} onChange={v=>setReq({...req, product_area:v})}/></Field>
      <Field label="Journey"><TextInput value={req.journey} onChange={v=>setReq({...req, journey:v})}/></Field>
    </div>
    <Field label="Screen Name"><TextInput value={req.screen_name} onChange={v=>setReq({...req, screen_name:v})}/></Field>
    <Field label="User Flow Context"><TextArea value={req.user_flow_context} onChange={v=>setReq({...req, user_flow_context:v})}/></Field>
    <Field label="Screen Text / Extracted UI Content"><TextArea value={req.screen_text} onChange={v=>setReq({...req, screen_text:v})}/></Field>
    <Field label="Risk Categories"><TagsInput value={req.risk_categories} onChange={v=>setReq({...req, risk_categories:v})}/></Field>
    <button onClick={run}>Run Persona Agent</button><span className="status">{status}</span>

    {result && <div className="result">
      <h2>Executive Summary</h2>
      <p>{result.executive_summary}</p>
      <h2>Persona Feedback</h2>
      {result.persona_feedback.map(f => <div className="finding" key={f.persona_id}>
        <h3>{f.persona_name} <span className={`sev ${f.severity}`}>{f.severity}</span></h3>
        <p><b>Why selected:</b> {f.why_selected}</p>
        <p><b>Likely reaction:</b> {f.likely_reaction}</p>
        <h4>Evidence</h4>
        <ul>{f.evidence_summary.map((x,i)=><li key={i}>{x}</li>)}</ul>
        <h4>Design implications</h4>
        <ul>{f.design_implications.map((x,i)=><li key={i}>{x}</li>)}</ul>
      </div>)}
      <h2>Relevant Pain Points</h2>
      {result.relevant_pain_points.map(p => <div className="mini" key={p.pain_point_id}><b>{p.theme}</b><p>{p.description}</p></div>)}
      <h2>Relevant Guardrails</h2>
      {result.relevant_guardrails.map(g => <div className="mini" key={g.guardrail_id}><b>{g.priority}: {g.title}</b><p>{g.description}</p></div>)}
      <h2>Prioritized Recommendations</h2>
      <ol>{result.prioritized_recommendations.map((r,i)=><li key={i}>{r}</li>)}</ol>
      <p className="disclaimer">{result.disclaimer}</p>
    </div>}
  </Card>
}

function LibraryViewer({reload}) {
  const [data, setData] = useState({personas:[], sources:[], facts:[], painPoints:[], guardrails:[]});
  useEffect(()=>{ 
    Promise.all([
      apiGet("/personas"), apiGet("/evidence/sources"), apiGet("/evidence/facts"), apiGet("/pain-points"), apiGet("/guardrails")
    ]).then(([personas, sources, facts, painPoints, guardrails])=>setData({personas, sources, facts, painPoints, guardrails})).catch(console.error)
  }, [reload]);
  return <Card title="Repository Viewer" icon={<Database size={20}/>}>
    <div className="stats">
      <div><b>{data.personas.length}</b><span>Personas</span></div>
      <div><b>{data.sources.length}</b><span>Evidence Sources</span></div>
      <div><b>{data.facts.length}</b><span>Evidence Facts</span></div>
      <div><b>{data.painPoints.length}</b><span>Pain Points</span></div>
      <div><b>{data.guardrails.length}</b><span>Guardrails</span></div>
    </div>
    <details><summary>Personas</summary><pre>{JSON.stringify(data.personas, null, 2)}</pre></details>
    <details><summary>Evidence Facts</summary><pre>{JSON.stringify(data.facts, null, 2)}</pre></details>
    <details><summary>Pain Points</summary><pre>{JSON.stringify(data.painPoints, null, 2)}</pre></details>
    <details><summary>Guardrails</summary><pre>{JSON.stringify(data.guardrails, null, 2)}</pre></details>
  </Card>
}

function App() {
  const [tab, setTab] = useState("run");
  const [reload, setReload] = useState(0);
  const refresh = () => setReload(x=>x+1);
  const tabs = [
    ["run", "Run Agent"],
    ["persona", "Persona Builder"],
    ["evidence", "Evidence Library"],
    ["pain", "Pain Points"],
    ["guardrail", "Guardrails"],
    ["repo", "Repository"]
  ];
  return <main>
    <header>
      <h1>PBM UX Research Agent</h1>
      <p>Low-code evidence-backed persona, pain point, and design guardrail platform</p>
    </header>
    <nav>{tabs.map(([id,label])=><button className={tab===id?"active":""} onClick={()=>setTab(id)} key={id}>{label}</button>)}</nav>
    {tab==="run" && <AgentRun />}
    {tab==="persona" && <PersonaBuilder refreshKey={refresh}/>}
    {tab==="evidence" && <EvidenceLibrary refreshKey={refresh}/>}
    {tab==="pain" && <PainPointBuilder refreshKey={refresh}/>}
    {tab==="guardrail" && <GuardrailBuilder refreshKey={refresh}/>}
    {tab==="repo" && <LibraryViewer reload={reload}/>}
  </main>
}

createRoot(document.getElementById("root")).render(<App />);
