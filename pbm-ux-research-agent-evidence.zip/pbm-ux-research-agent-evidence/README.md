# PBM UX Research Agent — Evidence-Backed Persona + Guardrail Platform

A local low-code/no-code platform for building PBM UX personas, ingesting prior research evidence, creating reusable pain point themes/design guardrails, and running evidence-backed persona analysis for future product screens.

## Included

- FastAPI backend
- React frontend
- DynamoDB Local
- DynamoDB Admin UI
- Evidence Library
- Pain Point Themes
- Design Guardrails
- Persona Builder
- Evidence-backed Persona Agent run screen
- Seed data from Check Coverage / Find a Pharmacy value proposition themes
- Docker Compose local setup

## Run locally

```bash
cp .env.example .env
docker compose up --build
```

Seed DynamoDB:

```bash
docker compose exec backend python scripts/create_tables.py
docker compose exec backend python scripts/seed_value_prop_evidence.py
```

Open:

- Frontend: http://localhost:5173
- API docs: http://localhost:8000/docs
- DynamoDB Admin: http://localhost:8001

## Guardrail

This platform is intended to complement, not replace, moderated UX research. Do not send raw PHI to LLMs. De-identify member feedback/call summaries before AI extraction.
