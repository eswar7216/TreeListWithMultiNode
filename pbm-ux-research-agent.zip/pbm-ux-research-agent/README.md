# PBM UX Research Agent Platform

This project is a local full-stack prototype for a low-code/no-code UX research agent experience for PBM member-facing products.

It lets UX/Product teams configure:

- Products and journeys
- Prototype screens
- Research studies
- Persona definitions
- Persona selection and simulation inputs

The first implemented capability is a **Persona Builder + Persona Agent workspace**. It stores configuration in DynamoDB so future products can be onboarded without code changes.

## Local stack

- Frontend: React + Vite
- Backend: FastAPI
- Database: DynamoDB Local
- Local DynamoDB UI: dynamodb-admin

## Run locally

```bash
cp .env.example .env
docker compose up --build
```

Open:

- Frontend: http://localhost:5173
- Backend API docs: http://localhost:8000/docs
- DynamoDB Admin: http://localhost:8001

## Seed sample data

After containers are running:

```bash
docker compose exec backend python scripts/seed.py
```

## Main screens

1. **Persona Builder** — create/edit PBM research personas.
2. **Persona Library** — view saved personas.
3. **Product Setup** — configure future products and journeys.
4. **Prototype Intake** — capture screen/user-flow context similar to usability study setup.
5. **Persona Agent Run** — select personas and generate simulated persona feedback.

## DynamoDB table design

Single table: `PbmUxResearch`

| Entity | PK | SK |
|---|---|---|
| Persona | `PERSONA#{persona_id}` | `METADATA` |
| Product | `PRODUCT#{product_id}` | `METADATA` |
| Journey | `PRODUCT#{product_id}` | `JOURNEY#{journey_id}` |
| Screen | `STUDY#{study_id}` | `SCREEN#{screen_id}` |
| Study | `STUDY#{study_id}` | `METADATA` |
| Agent Run | `STUDY#{study_id}` | `RUN#{run_id}` |

GSI1:

| Access pattern | GSI1PK | GSI1SK |
|---|---|---|
| List personas | `TYPE#PERSONA` | `NAME#{name}` |
| List products | `TYPE#PRODUCT` | `NAME#{name}` |
| List studies | `TYPE#STUDY` | `CREATED#{created_at}` |

## Current agent behavior

The current Persona Agent has deterministic rule-based persona selection and local simulation logic. You can later connect LiteLLM by replacing `app/services/persona_agent.py` simulation logic with an LLM call.

This output is AI-generated simulated persona feedback. It complements but does not replace moderated user research, UX researcher judgment, accessibility review, product review, legal/compliance review, or clinical review.
