# DynamoDB Objects

## Persona object

```json
{
  "PK": "PERSONA#persona_123",
  "SK": "METADATA",
  "GSI1PK": "TYPE#PERSONA",
  "GSI1SK": "NAME#cost-sensitive member",
  "entity_type": "PERSONA",
  "persona_id": "persona_123",
  "name": "Cost-Sensitive Member",
  "description": "...",
  "tags": ["cost", "savings"],
  "attributes": {
    "digital_comfort": "medium",
    "health_literacy": "medium",
    "cost_sensitivity": "high",
    "trust_level": "medium"
  },
  "goals": [],
  "likely_questions": [],
  "likely_friction_points": [],
  "recruiting_value": "...",
  "created_at": "2026-...",
  "updated_at": "2026-..."
}
```

## Product object

```json
{
  "PK": "PRODUCT#product_123",
  "SK": "METADATA",
  "GSI1PK": "TYPE#PRODUCT",
  "GSI1SK": "NAME#savings advisor",
  "entity_type": "PRODUCT",
  "product_id": "product_123",
  "product_name": "Savings Advisor",
  "default_persona_ids": [],
  "default_risk_categories": []
}
```

## Journey object

```json
{
  "PK": "PRODUCT#product_123",
  "SK": "JOURNEY#journey_123",
  "GSI1PK": "TYPE#JOURNEY#PRODUCT#product_123",
  "GSI1SK": "NAME#alternative medication recommendation",
  "entity_type": "JOURNEY"
}
```

## Agent run object

```json
{
  "PK": "STUDY#study_123",
  "SK": "RUN#run_123",
  "entity_type": "AGENT_RUN",
  "request": {},
  "selected_personas": [],
  "persona_feedback": []
}
```
