from __future__ import annotations

from app.db import ensure_table_exists
from app.models import PersonaCreate, ProductCreate, JourneyCreate
from app.services import create_persona, create_product, create_journey, list_personas, list_products


def seed():
    ensure_table_exists()
    if list_personas():
        print("Seed skipped: personas already exist")
        return

    personas = [
        PersonaCreate(
            name="Cost-Sensitive Member",
            description="Member who is highly motivated by lower prescription cost and wants clear savings information.",
            tags=["cost", "savings", "price", "copay", "price_comparison"],
            goals=["Understand how much they may pay", "Avoid surprise costs"],
            likely_questions=["Is this what I save or what I pay?", "Is this price guaranteed?", "Why is this option cheaper?"],
            likely_friction_points=["May distrust large price differences", "May misunderstand estimated cost"],
            recruiting_value="Validates cost and savings comprehension.",
        ),
        PersonaCreate(
            name="Medication-Switch Skeptic",
            description="Member who is cautious about switching medications and needs reassurance around doctor involvement.",
            tags=["medication_switching", "doctor_involvement", "trust", "preferred_alternative"],
            goals=["Understand why a change is recommended", "Know whether doctor approval is needed"],
            likely_questions=["Why is my insurance suggesting this?", "Will my doctor approve this?"],
            likely_friction_points=["May worry cheaper means lower quality", "May abandon the flow to call the doctor"],
            recruiting_value="Validates trust and medication-switching clarity.",
        ),
        PersonaCreate(
            name="Caregiver Managing Prescriptions",
            description="Caregiver who manages prescriptions for a spouse, parent, child, or dependent.",
            tags=["caregiver", "doctor_handoff", "download", "confirmation", "share"],
            goals=["Understand who the recommendation applies to", "Know what to share with the doctor"],
            likely_questions=["Who is this recommendation for?", "Can I download or share this?"],
            likely_friction_points=["Needs clear member identity", "Needs stronger confirmation-page structure"],
            recruiting_value="Validates caregiver and handoff scenarios.",
        ),
        PersonaCreate(
            name="Senior Member with Lower Digital Confidence",
            description="Senior member less comfortable with digital prescription workflows and benefit terminology.",
            tags=["accessibility", "plain_language", "low_digital_confidence", "cta_clarity"],
            goals=["Understand what the page asks them to do", "Avoid unintended changes"],
            likely_questions=["Am I changing my prescription now?", "What happens if I click Continue?"],
            likely_friction_points=["May struggle with vague CTAs", "May miss small cost details"],
            recruiting_value="Validates plain language, CTA clarity, and accessibility.",
        ),
    ]
    created_personas = [create_persona(p) for p in personas]

    product = create_product(ProductCreate(
        product_name="Savings Advisor",
        description="Member-facing experience that presents prescription savings recommendations.",
        default_persona_ids=[p.persona_id for p in created_personas],
        default_risk_categories=["cost_clarity", "savings_trust", "medication_switching", "doctor_involvement", "next_step_clarity"],
    ))
    create_journey(JourneyCreate(
        product_id=product.product_id,
        journey_name="Alternative Medication Recommendation",
        user_goal="Understand lower-cost medication options and know what action to take next.",
        business_goal="Help members reduce prescription cost through benefit-optimized changes.",
        expected_user_action="Review recommendations and continue to doctor or pharmacy handoff.",
        known_confusion_points=[
            "Member may expect to select a single medication",
            "Member may expect to finalize the medication change online",
            "Member may not understand doctor involvement",
            "Member may confuse amount paid with amount saved",
        ],
        risk_categories=["cost_clarity", "medication_switching", "doctor_involvement", "savings_trust", "next_step_clarity"],
    ))
    print("Seed complete")


if __name__ == "__main__":
    seed()
