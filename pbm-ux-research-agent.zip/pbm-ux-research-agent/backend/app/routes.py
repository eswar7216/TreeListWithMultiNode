from __future__ import annotations

from fastapi import APIRouter, HTTPException
from app.models import (
    PersonaCreate, Persona, ProductCreate, Product, JourneyCreate, Journey,
    StudyCreate, Study, PrototypeScreenCreate, PrototypeScreen, PersonaAgentRunRequest,
    PersonaAgentRunResponse,
)
from app.services import (
    create_persona, list_personas, get_persona, delete_persona,
    create_product, list_products, create_journey, list_journeys,
    create_study, list_studies, create_screen, list_screens,
)
from app.persona_agent import run_persona_agent

router = APIRouter(prefix="/api")


@router.get("/health")
def health():
    return {"status": "ok"}


@router.post("/personas", response_model=Persona)
def post_persona(payload: PersonaCreate):
    return create_persona(payload)


@router.get("/personas", response_model=list[Persona])
def get_personas():
    return list_personas()


@router.get("/personas/{persona_id}", response_model=Persona)
def get_persona_by_id(persona_id: str):
    persona = get_persona(persona_id)
    if not persona:
        raise HTTPException(status_code=404, detail="Persona not found")
    return persona


@router.delete("/personas/{persona_id}")
def remove_persona(persona_id: str):
    delete_persona(persona_id)
    return {"status": "deleted"}


@router.post("/products", response_model=Product)
def post_product(payload: ProductCreate):
    return create_product(payload)


@router.get("/products", response_model=list[Product])
def get_products():
    return list_products()


@router.post("/journeys", response_model=Journey)
def post_journey(payload: JourneyCreate):
    return create_journey(payload)


@router.get("/products/{product_id}/journeys", response_model=list[Journey])
def get_product_journeys(product_id: str):
    return list_journeys(product_id)


@router.post("/studies", response_model=Study)
def post_study(payload: StudyCreate):
    return create_study(payload)


@router.get("/studies", response_model=list[Study])
def get_studies():
    return list_studies()


@router.post("/screens", response_model=PrototypeScreen)
def post_screen(payload: PrototypeScreenCreate):
    return create_screen(payload)


@router.get("/studies/{study_id}/screens", response_model=list[PrototypeScreen])
def get_study_screens(study_id: str):
    return list_screens(study_id)


@router.post("/persona-agent/run", response_model=PersonaAgentRunResponse)
def run_persona_agent_endpoint(payload: PersonaAgentRunRequest):
    return run_persona_agent(payload)
