from __future__ import annotations

from decimal import Decimal
from app.models import (
    PersonaCreate, Persona, ProductCreate, Product, JourneyCreate, Journey,
    StudyCreate, Study, PrototypeScreenCreate, PrototypeScreen, now_iso, new_id
)
from app.repository import put_item, get_item, query_gsi1, query_pk, delete_item


def strip_keys(item: dict) -> dict:
    return {k: v for k, v in item.items() if k not in {"PK", "SK", "GSI1PK", "GSI1SK", "entity_type"}}


def create_persona(payload: PersonaCreate) -> Persona:
    ts = now_iso()
    persona = Persona(persona_id=new_id("persona"), created_at=ts, updated_at=ts, **payload.model_dump())
    item = persona.model_dump()
    item.update({
        "PK": f"PERSONA#{persona.persona_id}",
        "SK": "METADATA",
        "GSI1PK": "TYPE#PERSONA",
        "GSI1SK": f"NAME#{persona.name.lower()}",
        "entity_type": "PERSONA",
    })
    put_item(item)
    return persona


def list_personas() -> list[Persona]:
    return [Persona(**strip_keys(i)) for i in query_gsi1("TYPE#PERSONA")]


def get_persona(persona_id: str) -> Persona | None:
    item = get_item(f"PERSONA#{persona_id}", "METADATA")
    return Persona(**strip_keys(item)) if item else None


def delete_persona(persona_id: str) -> None:
    delete_item(f"PERSONA#{persona_id}", "METADATA")


def create_product(payload: ProductCreate) -> Product:
    ts = now_iso()
    product = Product(product_id=new_id("product"), created_at=ts, updated_at=ts, **payload.model_dump())
    item = product.model_dump()
    item.update({
        "PK": f"PRODUCT#{product.product_id}",
        "SK": "METADATA",
        "GSI1PK": "TYPE#PRODUCT",
        "GSI1SK": f"NAME#{product.product_name.lower()}",
        "entity_type": "PRODUCT",
    })
    put_item(item)
    return product


def list_products() -> list[Product]:
    return [Product(**strip_keys(i)) for i in query_gsi1("TYPE#PRODUCT")]


def get_product(product_id: str) -> Product | None:
    item = get_item(f"PRODUCT#{product_id}", "METADATA")
    return Product(**strip_keys(item)) if item else None


def create_journey(payload: JourneyCreate) -> Journey:
    ts = now_iso()
    journey = Journey(journey_id=new_id("journey"), created_at=ts, updated_at=ts, **payload.model_dump())
    item = journey.model_dump()
    item.update({
        "PK": f"PRODUCT#{journey.product_id}",
        "SK": f"JOURNEY#{journey.journey_id}",
        "GSI1PK": f"TYPE#JOURNEY#PRODUCT#{journey.product_id}",
        "GSI1SK": f"NAME#{journey.journey_name.lower()}",
        "entity_type": "JOURNEY",
    })
    put_item(item)
    return journey


def list_journeys(product_id: str) -> list[Journey]:
    items = query_pk(f"PRODUCT#{product_id}")
    return [Journey(**strip_keys(i)) for i in items if i.get("entity_type") == "JOURNEY"]


def create_study(payload: StudyCreate) -> Study:
    ts = now_iso()
    study = Study(study_id=new_id("study"), created_at=ts, updated_at=ts, **payload.model_dump())
    item = study.model_dump()
    item.update({
        "PK": f"STUDY#{study.study_id}",
        "SK": "METADATA",
        "GSI1PK": "TYPE#STUDY",
        "GSI1SK": f"CREATED#{study.created_at}",
        "entity_type": "STUDY",
    })
    put_item(item)
    return study


def list_studies() -> list[Study]:
    return [Study(**strip_keys(i)) for i in query_gsi1("TYPE#STUDY")]


def create_screen(payload: PrototypeScreenCreate) -> PrototypeScreen:
    ts = now_iso()
    screen = PrototypeScreen(screen_id=new_id("screen"), created_at=ts, updated_at=ts, **payload.model_dump())
    item = screen.model_dump()
    item.update({
        "PK": f"STUDY#{screen.study_id}",
        "SK": f"SCREEN#{screen.screen_id}",
        "GSI1PK": f"TYPE#SCREEN#STUDY#{screen.study_id}",
        "GSI1SK": f"NAME#{screen.screen_name.lower()}",
        "entity_type": "SCREEN",
    })
    put_item(item)
    return screen


def list_screens(study_id: str) -> list[PrototypeScreen]:
    items = query_pk(f"STUDY#{study_id}")
    return [PrototypeScreen(**strip_keys(i)) for i in items if i.get("entity_type") == "SCREEN"]
