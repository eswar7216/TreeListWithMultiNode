from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Literal
from uuid import uuid4
from pydantic import BaseModel, Field


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def new_id(prefix: str) -> str:
    return f"{prefix}_{uuid4().hex[:12]}"


class PersonaAttributes(BaseModel):
    digital_comfort: Literal["low", "medium", "high"] = "medium"
    health_literacy: Literal["low", "medium", "high"] = "medium"
    cost_sensitivity: Literal["low", "medium", "high"] = "medium"
    trust_level: Literal["low", "medium", "high"] = "medium"


class PersonaCreate(BaseModel):
    name: str
    description: str
    tags: list[str] = []
    attributes: PersonaAttributes = Field(default_factory=PersonaAttributes)
    goals: list[str] = []
    likely_questions: list[str] = []
    likely_friction_points: list[str] = []
    recruiting_value: str = ""
    domain: str = "PBM Member Experience"


class Persona(PersonaCreate):
    persona_id: str
    created_at: str
    updated_at: str


class ProductCreate(BaseModel):
    product_name: str
    domain: str = "PBM Member Experience"
    description: str = ""
    default_persona_ids: list[str] = []
    default_risk_categories: list[str] = []


class Product(ProductCreate):
    product_id: str
    created_at: str
    updated_at: str


class JourneyCreate(BaseModel):
    product_id: str
    journey_name: str
    user_goal: str = ""
    business_goal: str = ""
    expected_user_action: str = ""
    known_confusion_points: list[str] = []
    risk_categories: list[str] = []


class Journey(JourneyCreate):
    journey_id: str
    created_at: str
    updated_at: str


class StudyCreate(BaseModel):
    product_id: str
    journey_id: str | None = None
    study_name: str
    objective: str = ""
    methodology: str = "Moderated usability study with AI-assisted pre-research simulation."
    target_participants: str = ""


class Study(StudyCreate):
    study_id: str
    created_at: str
    updated_at: str


class PrototypeScreenCreate(BaseModel):
    study_id: str
    screen_name: str
    screen_purpose: str = ""
    user_flow_context: str = ""
    device_target: Literal["desktop", "mobile", "tablet"] = "desktop"
    screen_text: str = ""
    known_constraints: list[str] = []
    risk_categories: list[str] = []


class PrototypeScreen(PrototypeScreenCreate):
    screen_id: str
    created_at: str
    updated_at: str


class PersonaAgentRunRequest(BaseModel):
    product_id: str
    journey_id: str | None = None
    study_id: str | None = None
    screen_name: str
    user_flow_context: str
    screen_text: str = ""
    known_constraints: list[str] = []
    risk_categories: list[str] = []
    mode: Literal["library_only", "hybrid", "generate_only"] = "hybrid"
    max_personas: int = 6


class PersonaAgentFinding(BaseModel):
    persona_id: str
    persona_name: str
    likely_reaction: str
    likely_questions: list[str]
    likely_friction_points: list[str]
    pbm_specific_concerns: list[str]
    design_implications: list[str]
    severity: Literal["Low", "Medium", "High", "Critical"]
    human_review_flags: list[str]


class PersonaAgentRunResponse(BaseModel):
    run_id: str
    selected_personas: list[dict[str, Any]]
    generated_personas: list[dict[str, Any]]
    persona_feedback: list[PersonaAgentFinding]
    recommended_recruiting_criteria: list[str]
    disclaimer: str
    created_at: str
