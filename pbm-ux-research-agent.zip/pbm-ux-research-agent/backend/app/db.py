from __future__ import annotations

import time
import boto3
from botocore.exceptions import ClientError
from app.config import settings


def dynamodb_resource():
    return boto3.resource(
        "dynamodb",
        region_name=settings.aws_region,
        endpoint_url=settings.dynamodb_endpoint,
        aws_access_key_id="local",
        aws_secret_access_key="local",
    )


def dynamodb_client():
    return boto3.client(
        "dynamodb",
        region_name=settings.aws_region,
        endpoint_url=settings.dynamodb_endpoint,
        aws_access_key_id="local",
        aws_secret_access_key="local",
    )


def table():
    return dynamodb_resource().Table(settings.dynamodb_table)


def ensure_table_exists() -> None:
    client = dynamodb_client()
    existing = client.list_tables().get("TableNames", [])
    if settings.dynamodb_table in existing:
        return

    client.create_table(
        TableName=settings.dynamodb_table,
        KeySchema=[
            {"AttributeName": "PK", "KeyType": "HASH"},
            {"AttributeName": "SK", "KeyType": "RANGE"},
        ],
        AttributeDefinitions=[
            {"AttributeName": "PK", "AttributeType": "S"},
            {"AttributeName": "SK", "AttributeType": "S"},
            {"AttributeName": "GSI1PK", "AttributeType": "S"},
            {"AttributeName": "GSI1SK", "AttributeType": "S"},
        ],
        GlobalSecondaryIndexes=[
            {
                "IndexName": "GSI1",
                "KeySchema": [
                    {"AttributeName": "GSI1PK", "KeyType": "HASH"},
                    {"AttributeName": "GSI1SK", "KeyType": "RANGE"},
                ],
                "Projection": {"ProjectionType": "ALL"},
                "ProvisionedThroughput": {"ReadCapacityUnits": 5, "WriteCapacityUnits": 5},
            }
        ],
        BillingMode="PROVISIONED",
        ProvisionedThroughput={"ReadCapacityUnits": 5, "WriteCapacityUnits": 5},
    )

    for _ in range(30):
        try:
            desc = client.describe_table(TableName=settings.dynamodb_table)
            if desc["Table"]["TableStatus"] == "ACTIVE":
                return
        except ClientError:
            pass
        time.sleep(1)

    raise RuntimeError(f"DynamoDB table {settings.dynamodb_table} did not become ACTIVE")
