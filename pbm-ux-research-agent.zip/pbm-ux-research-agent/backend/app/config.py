from pydantic_settings import BaseSettings
from pydantic import Field


class Settings(BaseSettings):
    aws_region: str = Field(default="us-east-1", alias="AWS_REGION")
    dynamodb_endpoint: str = Field(default="http://localhost:8002", alias="DYNAMODB_ENDPOINT")
    dynamodb_table: str = Field(default="PbmUxResearch", alias="DYNAMODB_TABLE")
    backend_cors_origins: str = Field(default="http://localhost:5173", alias="BACKEND_CORS_ORIGINS")

    class Config:
        env_file = ".env"
        extra = "ignore"


settings = Settings()
