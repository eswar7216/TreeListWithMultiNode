from __future__ import annotations

from boto3.dynamodb.conditions import Key
from app.db import table


def put_item(item: dict) -> dict:
    table().put_item(Item=item)
    return item


def get_item(pk: str, sk: str) -> dict | None:
    response = table().get_item(Key={"PK": pk, "SK": sk})
    return response.get("Item")


def query_pk(pk: str) -> list[dict]:
    response = table().query(KeyConditionExpression=Key("PK").eq(pk))
    return response.get("Items", [])


def query_gsi1(gsi1pk: str) -> list[dict]:
    response = table().query(
        IndexName="GSI1",
        KeyConditionExpression=Key("GSI1PK").eq(gsi1pk),
    )
    return response.get("Items", [])


def delete_item(pk: str, sk: str) -> None:
    table().delete_item(Key={"PK": pk, "SK": sk})
