from __future__ import annotations

from app.models import PersonaAgentRunRequest, PersonaAgentRunResponse, PersonaAgentFinding, now_iso, new_id
from app.services import list_personas, get_product, list_journeys
from app.repository import put_item


def _matches(persona: dict, text: str, risks: list[str]) -> tuple[int, list[str]]:
    score = 0
    matched = []
    tags = persona.get("tags", [])
    haystack = text.lower()
    for tag in tags:
        if tag.lower().replace("_", " ") in haystack or tag in risks:
            score += 2
            matched.append(tag)
    for q in persona.get("likely_questions", []):
        for token in q.lower().replace("?", "").split():
            if len(token) > 5 and token in haystack:
                score += 1
                matched.append(token)
    return score, sorted(set(matched))


def _fallback_generated_personas(request: PersonaAgentRunRequest) -> list[dict]:
    generated = []
    risks = set(request.risk_categories)
    if "doctor_involvement" in risks:
        generated.append({
            "persona_id": "generated_doctor_dependent_decision_maker",
            "name": "Doctor-Dependent Decision Maker",
            "description": "Member wants physician confirmation before acting on prescription recommendations.",
            "tags": ["doctor_involvement", "next_step_clarity", "handoff"],
            "attributes": {"digital_comfort":"medium", "health_literacy":"medium", "cost_sensitivity":"medium", "trust_level":"medium"},
            "goals": ["Know whether the doctor must approve", "Understand what to ask the doctor"],
            "likely_questions": ["Can I complete this now?", "Will my doctor choose the medication?"],
            "likely_friction_points": ["May stop if doctor involvement is unclear"],
            "recruiting_value": "Validates doctor handoff and next-step clarity.",
            "why_generated": "Generated because doctor involvement is a selected risk area."
        })
    if "coverage_rules" in risks:
        generated.append({
            "persona_id": "generated_new_plan_member",
            "name": "New Plan Member",
            "description": "Member is unfamiliar with plan rules, coverage language, and PBM terminology.",
            "tags": ["coverage_rules", "plain_language", "benefit"],
            "attributes": {"digital_comfort":"medium", "health_literacy":"low", "cost_sensitivity":"medium", "trust_level":"medium"},
            "goals": ["Understand what is covered", "Know whether action is required"],
            "likely_questions": ["Is this covered?", "Is this required by my plan?"],
            "likely_friction_points": ["May confuse recommendation with requirement"],
            "recruiting_value": "Validates coverage and terminology clarity.",
            "why_generated": "Generated because coverage rules are in scope."
        })
    return generated[:3]


def run_persona_agent(request: PersonaAgentRunRequest) -> PersonaAgentRunResponse:
    personas = [p.model_dump() for p in list_personas()]
    product = get_product(request.product_id)
    product_defaults = product.default_persona_ids if product else []

    context_text = " ".join([
        request.screen_name,
        request.user_flow_context,
        request.screen_text,
        " ".join(request.known_constraints),
        " ".join(request.risk_categories),
    ])

    selected = []
    selected_ids = set()

    for persona in personas:
        if persona["persona_id"] in product_defaults:
            selected.append({
                "persona": persona,
                "why_selected": "Included as a default persona for the selected product.",
                "matched_terms": []
            })
            selected_ids.add(persona["persona_id"])

    ranked = []
    for persona in personas:
        score, matched = _matches(persona, context_text, request.risk_categories)
        if score > 0 and persona["persona_id"] not in selected_ids:
            ranked.append((score, persona, matched))
    ranked.sort(key=lambda x: x[0], reverse=True)

    for _, persona, matched in ranked:
        if len(selected) >= request.max_personas:
            break
        selected.append({
            "persona": persona,
            "why_selected": "Selected because persona tags/questions match the screen context or risk categories.",
            "matched_terms": matched,
        })
        selected_ids.add(persona["persona_id"])

    generated = []
    if request.mode in {"hybrid", "generate_only"}:
        generated = _fallback_generated_personas(request)

    feedback = []
    all_personas = [s["persona"] for s in selected] + generated
    for persona in all_personas[:request.max_personas]:
        name = persona["name"]
        tags = persona.get("tags", [])
        severity = "High" if any(t in tags for t in ["cost", "savings", "medication_switching", "doctor_involvement", "coverage_rules"]) else "Medium"
        flags = ["UX"]
        if any(t in tags for t in ["cost", "savings", "coverage_rules", "medication_switching", "doctor_involvement"]):
            flags.append("Product")
            flags.append("Compliance")
        if any(t in tags for t in ["accessibility", "low_digital_confidence", "plain_language"]):
            flags.append("Accessibility")

        feedback.append(PersonaAgentFinding(
            persona_id=persona["persona_id"],
            persona_name=name,
            likely_reaction=f"{name} may understand the overall purpose, but may need clearer language around what action is expected and whether the recommendation is optional, estimated, or final.",
            likely_questions=persona.get("likely_questions", [])[:4],
            likely_friction_points=persona.get("likely_friction_points", [])[:4],
            pbm_specific_concerns=[
                "Cost and savings should be labeled as estimated unless guaranteed.",
                "Doctor or pharmacy involvement should be introduced before the final step.",
                "PBM terms should be explained in member-friendly language.",
            ],
            design_implications=[
                "Use a descriptive CTA instead of generic Continue when the next step has consequences.",
                "Clarify whether the member is reviewing, selecting, confirming, or downloading information.",
                "Add plain-language helper text for cost, coverage, medication, and doctor handoff concepts.",
            ],
            severity=severity,
            human_review_flags=sorted(set(flags)),
        ))

    criteria = {
        "Participants should have active health insurance.",
        "Participants should currently take or manage at least one prescription medication.",
    }
    joined = str(all_personas).lower()
    if "cost" in joined or "savings" in joined:
        criteria.add("Include participants who are sensitive to prescription cost.")
    if "caregiver" in joined:
        criteria.add("Include participants who manage prescriptions for someone else.")
    if "switch" in joined or "alternative" in joined:
        criteria.add("Include a mix of participants with and without prior medication-switching experience.")
    if "senior" in joined or "low" in joined:
        criteria.add("Include older adults or participants with lower digital confidence.")

    run_id = new_id("run")
    response = PersonaAgentRunResponse(
        run_id=run_id,
        selected_personas=selected,
        generated_personas=generated,
        persona_feedback=feedback,
        recommended_recruiting_criteria=sorted(criteria),
        disclaimer="This is AI-generated simulated persona feedback. It complements but does not replace moderated user research, UX researcher judgment, accessibility review, product review, legal/compliance review, or clinical review.",
        created_at=now_iso(),
    )

    if request.study_id:
        item = response.model_dump()
        item.update({
            "PK": f"STUDY#{request.study_id}",
            "SK": f"RUN#{run_id}",
            "GSI1PK": f"TYPE#RUN#STUDY#{request.study_id}",
            "GSI1SK": f"CREATED#{response.created_at}",
            "entity_type": "AGENT_RUN",
            "request": request.model_dump(),
        })
        put_item(item)

    return response
