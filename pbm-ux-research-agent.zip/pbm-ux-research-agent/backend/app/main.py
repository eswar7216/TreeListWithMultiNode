from __future__ import annotations

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.config import settings
from app.db import ensure_table_exists
from app.routes import router

app = FastAPI(title="PBM UX Research Agent API", version="0.1.0")

origins = [origin.strip() for origin in settings.backend_cors_origins.split(",")]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def startup() -> None:
    ensure_table_exists()


app.include_router(router)
