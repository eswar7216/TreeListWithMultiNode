import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import './styles.css';

const API = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000';

type Persona = {
  persona_id: string;
  name: string;
  description: string;
  tags: string[];
  attributes: Record<string, string>;
  goals: string[];
  likely_questions: string[];
  likely_friction_points: string[];
  recruiting_value: string;
};

type Product = { product_id: string; product_name: string; default_persona_ids: string[]; default_risk_categories: string[]; description: string; domain: string };
type Journey = { journey_id: string; journey_name: string; product_id: string; risk_categories: string[]; user_goal: string; business_goal: string; expected_user_action: string; known_confusion_points: string[] };

async function api<T>(path: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${API}${path}`, {
    headers: { 'Content-Type': 'application/json', ...(options?.headers || {}) },
    ...options,
  });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

function splitLines(value: string): string[] {
  return value.split('\n').map(v => v.trim()).filter(Boolean);
}

function Pill({ children }: { children: React.ReactNode }) {
  return <span className="pill">{children}</span>;
}

function PersonaBuilder({ onSaved }: { onSaved: () => void }) {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [tags, setTags] = useState('cost\nsavings\nplain_language');
  const [goals, setGoals] = useState('Understand what action to take next');
  const [questions, setQuestions] = useState('What happens if I continue?');
  const [friction, setFriction] = useState('May misunderstand whether the recommendation is optional or required');
  const [recruitingValue, setRecruitingValue] = useState('Validates member comprehension for this journey.');
  const [digital, setDigital] = useState('medium');
  const [health, setHealth] = useState('medium');
  const [cost, setCost] = useState('medium');
  const [trust, setTrust] = useState('medium');
  const [message, setMessage] = useState('');

  async function save() {
    await api('/api/personas', {
      method: 'POST',
      body: JSON.stringify({
        name, description, tags: splitLines(tags), goals: splitLines(goals), likely_questions: splitLines(questions),
        likely_friction_points: splitLines(friction), recruiting_value: recruitingValue,
        attributes: { digital_comfort: digital, health_literacy: health, cost_sensitivity: cost, trust_level: trust }
      })
    });
    setMessage('Persona saved to DynamoDB.');
    setName('');
    setDescription('');
    onSaved();
  }

  return <section className="card">
    <h2>Persona Builder</h2>
    <p className="muted">Define reusable research personas without code changes. These personas are stored in DynamoDB and used by the Persona Agent.</p>
    <div className="grid two">
      <label>Name<input value={name} onChange={e => setName(e.target.value)} placeholder="Cost-Sensitive Member" /></label>
      <label>Recruiting value<input value={recruitingValue} onChange={e => setRecruitingValue(e.target.value)} /></label>
    </div>
    <label>Description<textarea value={description} onChange={e => setDescription(e.target.value)} placeholder="Member profile..." /></label>
    <div className="grid four">
      <label>Digital comfort<select value={digital} onChange={e => setDigital(e.target.value)}><option>low</option><option>medium</option><option>high</option></select></label>
      <label>Health literacy<select value={health} onChange={e => setHealth(e.target.value)}><option>low</option><option>medium</option><option>high</option></select></label>
      <label>Cost sensitivity<select value={cost} onChange={e => setCost(e.target.value)}><option>low</option><option>medium</option><option>high</option></select></label>
      <label>Trust level<select value={trust} onChange={e => setTrust(e.target.value)}><option>low</option><option>medium</option><option>high</option></select></label>
    </div>
    <div className="grid two">
      <label>Tags, one per line<textarea value={tags} onChange={e => setTags(e.target.value)} /></label>
      <label>Goals, one per line<textarea value={goals} onChange={e => setGoals(e.target.value)} /></label>
      <label>Likely questions, one per line<textarea value={questions} onChange={e => setQuestions(e.target.value)} /></label>
      <label>Likely friction points, one per line<textarea value={friction} onChange={e => setFriction(e.target.value)} /></label>
    </div>
    <button onClick={save} disabled={!name || !description}>Save Persona</button>
    {message && <p className="success">{message}</p>}
  </section>
}

function PersonaLibrary({ personas, refresh }: { personas: Persona[], refresh: () => void }) {
  async function remove(id: string) {
    await api(`/api/personas/${id}`, { method: 'DELETE' });
    refresh();
  }
  return <section className="card">
    <h2>Persona Library</h2>
    <div className="list">
      {personas.map(p => <div className="item" key={p.persona_id}>
        <div className="itemHeader"><h3>{p.name}</h3><button className="secondary" onClick={() => remove(p.persona_id)}>Delete</button></div>
        <p>{p.description}</p>
        <div>{p.tags.map(t => <Pill key={t}>{t}</Pill>)}</div>
        <p className="muted">Questions: {p.likely_questions.join(' · ')}</p>
      </div>)}
      {!personas.length && <p className="muted">No personas yet. Use the seed script or create one above.</p>}
    </div>
  </section>
}

function ProductSetup({ products, personas, refresh }: { products: Product[], personas: Persona[], refresh: () => void }) {
  const [productName, setProductName] = useState('Savings Advisor');
  const [description, setDescription] = useState('Member-facing experience for prescription savings recommendations.');
  const [riskCategories, setRiskCategories] = useState('cost_clarity\nsavings_trust\nmedication_switching\ndoctor_involvement\nnext_step_clarity');
  const [selectedPersonaIds, setSelectedPersonaIds] = useState<string[]>([]);
  const [selectedProduct, setSelectedProduct] = useState('');
  const [journeyName, setJourneyName] = useState('Alternative Medication Recommendation');
  const [userGoal, setUserGoal] = useState('Understand lower-cost medication options and know what action to take next.');
  const [journeyMessage, setJourneyMessage] = useState('');

  async function saveProduct() {
    await api('/api/products', { method: 'POST', body: JSON.stringify({ product_name: productName, description, default_persona_ids: selectedPersonaIds, default_risk_categories: splitLines(riskCategories) }) });
    refresh();
  }
  async function saveJourney() {
    await api('/api/journeys', { method: 'POST', body: JSON.stringify({ product_id: selectedProduct, journey_name: journeyName, user_goal: userGoal, business_goal: 'Improve member comprehension before formal usability research.', expected_user_action: 'Review recommendations and continue.', known_confusion_points: ['Member may not know what happens next'], risk_categories: splitLines(riskCategories) }) });
    setJourneyMessage('Journey saved.');
  }
  return <section className="card">
    <h2>Product and Journey Setup</h2>
    <div className="grid two">
      <label>Product name<input value={productName} onChange={e => setProductName(e.target.value)} /></label>
      <label>Risk categories<textarea value={riskCategories} onChange={e => setRiskCategories(e.target.value)} /></label>
    </div>
    <label>Description<textarea value={description} onChange={e => setDescription(e.target.value)} /></label>
    <label>Default personas<select multiple value={selectedPersonaIds} onChange={e => setSelectedPersonaIds(Array.from(e.target.selectedOptions).map(o => o.value))}>{personas.map(p => <option key={p.persona_id} value={p.persona_id}>{p.name}</option>)}</select></label>
    <button onClick={saveProduct}>Save Product</button>
    <hr />
    <h3>Create Journey</h3>
    <label>Product<select value={selectedProduct} onChange={e => setSelectedProduct(e.target.value)}><option value="">Select product</option>{products.map(p => <option key={p.product_id} value={p.product_id}>{p.product_name}</option>)}</select></label>
    <div className="grid two">
      <label>Journey name<input value={journeyName} onChange={e => setJourneyName(e.target.value)} /></label>
      <label>User goal<input value={userGoal} onChange={e => setUserGoal(e.target.value)} /></label>
    </div>
    <button disabled={!selectedProduct} onClick={saveJourney}>Save Journey</button>
    {journeyMessage && <p className="success">{journeyMessage}</p>}
  </section>
}

function AgentRun({ products }: { products: Product[] }) {
  const [productId, setProductId] = useState('');
  const [journeys, setJourneys] = useState<Journey[]>([]);
  const [journeyId, setJourneyId] = useState('');
  const [screenName, setScreenName] = useState('Rx Configuration');
  const [context, setContext] = useState('Member reviews recommended medication, pharmacy, and 3-month supply changes to lower prescription cost.');
  const [screenText, setScreenText] = useState('Recommended changes. Switch to a lower cost alternative. Switch to approved pharmacy. Switch to 3-month supply. No changes $523.68. With changes $8.06. Continue.');
  const [risks, setRisks] = useState('cost_clarity\nmedication_switching\ndoctor_involvement\nnext_step_clarity');
  const [constraints, setConstraints] = useState('Some changes may require doctor involvement.\nMember may not finalize medication changes in this flow.\nDisplayed costs may be estimates.');
  const [result, setResult] = useState<any>(null);

  useEffect(() => {
    if (productId) api<Journey[]>(`/api/products/${productId}/journeys`).then(setJourneys);
  }, [productId]);

  async function run() {
    const res = await api('/api/persona-agent/run', { method: 'POST', body: JSON.stringify({ product_id: productId, journey_id: journeyId || null, screen_name: screenName, user_flow_context: context, screen_text: screenText, known_constraints: splitLines(constraints), risk_categories: splitLines(risks), mode: 'hybrid', max_personas: 6 }) });
    setResult(res);
  }

  return <section className="card">
    <h2>Persona Agent Run</h2>
    <p className="muted">This is the replacement experience for early persona-driven usability preparation before formal testing.</p>
    <div className="grid two">
      <label>Product<select value={productId} onChange={e => setProductId(e.target.value)}><option value="">Select product</option>{products.map(p => <option key={p.product_id} value={p.product_id}>{p.product_name}</option>)}</select></label>
      <label>Journey<select value={journeyId} onChange={e => setJourneyId(e.target.value)}><option value="">None</option>{journeys.map(j => <option key={j.journey_id} value={j.journey_id}>{j.journey_name}</option>)}</select></label>
    </div>
    <label>Screen name<input value={screenName} onChange={e => setScreenName(e.target.value)} /></label>
    <label>User flow context<textarea value={context} onChange={e => setContext(e.target.value)} /></label>
    <label>Screen text / extracted Figma content<textarea value={screenText} onChange={e => setScreenText(e.target.value)} /></label>
    <div className="grid two"><label>Risk categories<textarea value={risks} onChange={e => setRisks(e.target.value)} /></label><label>Known constraints<textarea value={constraints} onChange={e => setConstraints(e.target.value)} /></label></div>
    <button disabled={!productId} onClick={run}>Run Persona Agent</button>
    {result && <div className="result">
      <h3>Selected Personas</h3>
      {result.selected_personas.map((s: any) => <div className="item" key={s.persona.persona_id}><h4>{s.persona.name}</h4><p>{s.why_selected}</p></div>)}
      <h3>Simulated Persona Feedback</h3>
      {result.persona_feedback.map((f: any) => <div className="item" key={f.persona_id}><h4>{f.persona_name} <span className="severity">{f.severity}</span></h4><p>{f.likely_reaction}</p><b>Questions</b><ul>{f.likely_questions.map((q: string) => <li key={q}>{q}</li>)}</ul><b>Design implications</b><ul>{f.design_implications.map((d: string) => <li key={d}>{d}</li>)}</ul></div>)}
      <h3>Recruiting Criteria</h3><ul>{result.recommended_recruiting_criteria.map((c: string) => <li key={c}>{c}</li>)}</ul>
      <p className="muted">{result.disclaimer}</p>
    </div>}
  </section>
}

function App() {
  const [tab, setTab] = useState('agent');
  const [personas, setPersonas] = useState<Persona[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  async function refresh() {
    setPersonas(await api('/api/personas'));
    setProducts(await api('/api/products'));
  }
  useEffect(() => { refresh(); }, []);
  return <div>
    <header><h1>PBM UX Research Agent</h1><p>Low-code/no-code persona and usability research workspace</p></header>
    <nav>
      <button className={tab==='agent'?'active':''} onClick={() => setTab('agent')}>Persona Agent</button>
      <button className={tab==='builder'?'active':''} onClick={() => setTab('builder')}>Persona Builder</button>
      <button className={tab==='library'?'active':''} onClick={() => setTab('library')}>Persona Library</button>
      <button className={tab==='product'?'active':''} onClick={() => setTab('product')}>Product Setup</button>
    </nav>
    <main>
      {tab === 'agent' && <AgentRun products={products} />}
      {tab === 'builder' && <PersonaBuilder onSaved={refresh} />}
      {tab === 'library' && <PersonaLibrary personas={personas} refresh={refresh} />}
      {tab === 'product' && <ProductSetup products={products} personas={personas} refresh={refresh} />}
    </main>
  </div>
}

createRoot(document.getElementById('root')!).render(<App />);
