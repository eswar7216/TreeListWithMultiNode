import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import { CheckCircle2, Circle, Upload, Users, Settings, Play, BookOpen, Plus, X } from "lucide-react";
import { apiGet, apiPost, apiPut, uploadKnowledge } from "./api/client";
import "./styles.css";

type Config = Record<string, any>;

const emptyPersona = {
  persona_id: "",
  name: "",
  description: "",
  tags: [],
  attributes: { digital_comfort: "medium", health_literacy: "medium", cost_sensitivity: "medium", trust_level: "medium" },
  goals: [], likely_questions: [], likely_friction_points: [], recruiting_value: "", evidence_source_ids: [], is_active: true
};

function App() {
  const [products, setProducts] = useState<Config[]>([]);
  const [journeys, setJourneys] = useState<Config[]>([]);
  const [personas, setPersonas] = useState<Config[]>([]);
  const [knowledge, setKnowledge] = useState<Config[]>([]);
  const [productId, setProductId] = useState("unified_medication_decision");
  const [journeyId, setJourneyId] = useState("check_coverage_find_pharmacy");
  const [screenName, setScreenName] = useState("Decision-ready results page");
  const [figmaUrl, setFigmaUrl] = useState("");
  const [screenText, setScreenText] = useState("");
  const [flowContext, setFlowContext] = useState("Member checks whether a medication is covered, which pharmacy is eligible/preferred, what it will cost, and what to do next.");
  const [selectedPersonas, setSelectedPersonas] = useState<string[]>([]);
  const [selectedKnowledge, setSelectedKnowledge] = useState<string[]>([]);
  const [result, setResult] = useState<any>(null);
  const [running, setRunning] = useState(false);
  const [personaModal, setPersonaModal] = useState(false);
  const [configModal, setConfigModal] = useState(false);
  const [knowledgeModal, setKnowledgeModal] = useState(false);

  async function refresh() {
    const p = await apiGet("/configs/product"); setProducts(p.items || []);
    const ps = await apiGet("/configs/persona"); setPersonas(ps.items || []);
    const k = await apiGet("/knowledge/sources"); setKnowledge(k.items || []);
    if (productId) {
      const j = await apiGet(`/configs/journey?parent_id=${productId}`); setJourneys(j.items || []);
    }
  }
  useEffect(() => { refresh().catch(console.error); }, []);
  useEffect(() => { if (productId) apiGet(`/configs/journey?parent_id=${productId}`).then(r=>setJourneys(r.items||[])); }, [productId]);

  const selectedProduct = products.find(p => p.product_id === productId);
  useEffect(() => {
    if (selectedProduct && selectedPersonas.length === 0) setSelectedPersonas(selectedProduct.default_persona_ids || []);
  }, [selectedProduct]);

  async function run() {
    setRunning(true); setResult(null);
    try {
      const payload = {
        product_id: productId,
        journey_id: journeyId || null,
        screen_name: screenName,
        figma_url: figmaUrl || null,
        device_target: "desktop",
        user_flow_context: flowContext,
        screen_text: screenText,
        selected_persona_ids: selectedPersonas,
        knowledge_source_ids: selectedKnowledge,
        known_constraints: ["Costs may be estimates unless explicitly guaranteed.", "Clinical or coverage language requires human review."],
      };
      const r = await apiPost("/runs/usability", payload);
      setResult(r);
    } finally { setRunning(false); }
  }

  return <div className="app">
    <header className="hero">
      <div>
        <div className="eyebrow">Evernorth Health Services · PBM Digital Experience</div>
        <h1>UserX Agent</h1>
        <p>Figma screen-reader usability testing with persona simulation, accessibility review, PBM risk checks, and uploaded value proposition knowledge.</p>
      </div>
      <button className="secondary" onClick={()=>setConfigModal(true)}><Settings size={18}/> Configure</button>
    </header>

    <main className="grid">
      <section className="panel setup">
        <h2>Run usability test</h2>
        <label>Product</label>
        <select value={productId} onChange={e=>setProductId(e.target.value)}>{products.map(p=><option key={p.product_id} value={p.product_id}>{p.name}</option>)}</select>
        <label>Journey</label>
        <select value={journeyId} onChange={e=>setJourneyId(e.target.value)}>{journeys.map(j=><option key={j.journey_id} value={j.journey_id}>{j.name}</option>)}</select>
        <label>Screen name</label><input value={screenName} onChange={e=>setScreenName(e.target.value)} />
        <label>Figma URL</label><input value={figmaUrl} onChange={e=>setFigmaUrl(e.target.value)} placeholder="https://www.figma.com/design/..." />
        <label>User flow context</label><textarea value={flowContext} onChange={e=>setFlowContext(e.target.value)} />
        <label>Manual screen text / fallback</label><textarea value={screenText} onChange={e=>setScreenText(e.target.value)} placeholder="Paste Figma text, visible screen copy, or OCR if Figma token is unavailable." />

        <div className="row between"><h3><Users size={18}/> Personas</h3><button className="link" onClick={()=>setPersonaModal(true)}><Plus size={16}/> Build persona</button></div>
        <div className="chips">{personas.map(p=><label key={p.persona_id} className="chip"><input type="checkbox" checked={selectedPersonas.includes(p.persona_id)} onChange={e=>setSelectedPersonas(s=>e.target.checked?[...new Set([...s,p.persona_id])]:s.filter(x=>x!==p.persona_id))}/>{p.name}</label>)}</div>
        <button className="link wide" onClick={()=>setPersonaModal(true)}>Persona does not exist? Create one in modal</button>

        <div className="row between"><h3><BookOpen size={18}/> Supplemental knowledge</h3><button className="link" onClick={()=>setKnowledgeModal(true)}><Upload size={16}/> Upload</button></div>
        <div className="chips">{knowledge.map(k=><label key={k.source_id} className="chip"><input type="checkbox" checked={selectedKnowledge.includes(k.source_id)} onChange={e=>setSelectedKnowledge(s=>e.target.checked?[...new Set([...s,k.source_id])]:s.filter(x=>x!==k.source_id))}/>{k.title}</label>)}</div>

        <button className="primary" disabled={running} onClick={run}><Play size={18}/>{running ? "Agent running..." : "Run UserX usability test"}</button>
      </section>

      <section className="panel progress">
        <h2>Agent flow</h2>
        <Progress result={result} running={running}/>
        {result && <Report result={result}/>}        
      </section>
    </main>

    {personaModal && <PersonaModal onClose={()=>setPersonaModal(false)} onSaved={()=>{setPersonaModal(false); refresh();}} />}
    {knowledgeModal && <KnowledgeModal productId={productId} journeyId={journeyId} onClose={()=>setKnowledgeModal(false)} onSaved={()=>{setKnowledgeModal(false); refresh();}} />}
    {configModal && <ConfigModal onClose={()=>setConfigModal(false)} onSaved={refresh}/>}    
  </div>
}

function Progress({result, running}: any) {
  const steps = result?.progress || [
    {step_id:"screen_reader",label:"Figma Screen Reader",detail:"Extract reading order and UI semantics", status: running?"running":"pending"},
    {step_id:"knowledge",label:"Supplemental Knowledge",detail:"Value proposition and evidence retrieval", status:"pending"},
    {step_id:"ux_heuristics",label:"UX Heuristics",detail:"Task clarity and usability review", status:"pending"},
    {step_id:"accessibility",label:"Accessibility",detail:"WCAG-oriented simulated review", status:"pending"},
    {step_id:"persona_simulation",label:"Persona Agents",detail:"Configured persona feedback", status:"pending"},
    {step_id:"knowledge_synthesis",label:"Evidence Synthesis",detail:"Apply knowledge base", status:"pending"},
    {step_id:"final_synthesis",label:"Synthesis",detail:"Prioritized report", status:"pending"}
  ];
  return <div className="steps">{steps.map((s:any)=><div className={`step ${s.status}`} key={s.step_id}>{s.status==="completed"?<CheckCircle2/>:<Circle/>}<div><b>{s.label}</b><p>{s.detail}</p></div></div>)}</div>
}

function Report({result}: any) {
  return <div className="report">
    <h2>Executive Summary</h2>
    <div className="summary">{result.executive_summary}</div>
    <div className="readiness">Readiness: <b>{result.readiness}</b></div>
    <h2>Prioritized findings</h2>
    {result.findings?.length ? result.findings.map((f:any, i:number)=><div className="finding" key={i}>
      <div className="row between"><h3>{i+1}. {f.title}</h3><span className={`severity ${f.severity}`}>{f.severity}</span></div>
      <p><b>Observation:</b> {f.observation}</p><p><b>Member impact:</b> {f.member_impact}</p><p><b>Recommendation:</b> {f.recommendation}</p>
      {!!f.evidence?.length && <p><b>Evidence:</b> {f.evidence.join(" · ")}</p>}
    </div>) : <p className="muted">No findings returned. Check LiteLLM configuration or prompt templates.</p>}
    <h2>Screen reader extraction</h2>
    <div className="codebox">{result.screen_reader?.reading_order?.slice(0,30).map((x:string,i:number)=><div key={i}>{i+1}. {x}</div>)}</div>
    <p className="disclaimer">{result.disclaimer}</p>
  </div>
}

function PersonaModal({onClose,onSaved}:any){
  const [p,setP]=useState<any>({...emptyPersona});
  function csv(v:string){return v.split("\n").map(x=>x.trim()).filter(Boolean)}
  async function save(){
    const id=p.persona_id || p.name.toLowerCase().replace(/[^a-z0-9]+/g,"_").replace(/^_|_$/g,"");
    const payload={...p, persona_id:id, tags: typeof p.tags === 'string' ? p.tags.split(',').map((x:string)=>x.trim()).filter(Boolean):p.tags, goals:csv(p.goalsText||''), likely_questions:csv(p.questionsText||''), likely_friction_points:csv(p.frictionText||'')};
    delete payload.goalsText; delete payload.questionsText; delete payload.frictionText;
    await apiPut(`/configs/persona/${id}`, payload); onSaved();
  }
  return <Modal title="Build persona" onClose={onClose}><label>Name</label><input value={p.name} onChange={e=>setP({...p,name:e.target.value})}/><label>Description</label><textarea value={p.description} onChange={e=>setP({...p,description:e.target.value})}/><label>Tags comma-separated</label><input onChange={e=>setP({...p,tags:e.target.value})}/><label>Goals one per line</label><textarea onChange={e=>setP({...p,goalsText:e.target.value})}/><label>Likely questions one per line</label><textarea onChange={e=>setP({...p,questionsText:e.target.value})}/><label>Likely friction points one per line</label><textarea onChange={e=>setP({...p,frictionText:e.target.value})}/><button className="primary" onClick={save}>Save persona to DynamoDB</button></Modal>
}

function KnowledgeModal({productId,journeyId,onClose,onSaved}:any){
  const [file,setFile]=useState<File|null>(null); const [title,setTitle]=useState(""); const [tags,setTags]=useState("value-proposition, evidence, usability");
  async function save(){ if(!file) return; const form=new FormData(); form.append("file",file); form.append("title",title||file.name); form.append("product_ids",productId); form.append("journey_ids",journeyId||""); form.append("tags",tags); await uploadKnowledge(form); onSaved(); }
  return <Modal title="Upload supplemental knowledge" onClose={onClose}><p>Upload value proposition deck, research report, feedback summary, or care-call pain point document. It is chunked and stored in DynamoDB as supplemental knowledge.</p><input type="file" onChange={e=>setFile(e.target.files?.[0]||null)}/><label>Title</label><input value={title} onChange={e=>setTitle(e.target.value)}/><label>Tags comma-separated</label><input value={tags} onChange={e=>setTags(e.target.value)}/><button className="primary" onClick={save}>Upload to knowledge base</button></Modal>
}

function ConfigModal({onClose,onSaved}:any){
  return <Modal title="Configuration center" onClose={onClose}><p>All runtime configuration is stored in DynamoDB. Use the API docs for full CRUD, or extend this modal with product, journey, risk checklist, and prompt template forms.</p><ul><li>Products: /api/configs/product</li><li>Journeys: /api/configs/journey?parent_id=PRODUCT_ID</li><li>Personas: /api/configs/persona</li><li>Risk checklists: /api/configs/risk_checklist</li><li>Prompt templates: /api/configs/prompt_template</li></ul><button onClick={onSaved} className="secondary">Refresh configs</button></Modal>
}

function Modal({title,onClose,children}:any){return <div className="modalBack"><div className="modal"><div className="row between"><h2>{title}</h2><button className="icon" onClick={onClose}><X/></button></div>{children}</div></div>}

createRoot(document.getElementById("root")!).render(<App/>);
