export type ConfigItem = Record<string, any>;
export type Finding = {
  title: string;
  category: string;
  severity: string;
  observation: string;
  member_impact: string;
  recommendation: string;
  evidence?: string[];
  impacted_personas?: string[];
  human_review_flags?: string[];
  priority_score?: number;
};
