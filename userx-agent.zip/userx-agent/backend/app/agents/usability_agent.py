from __future__ import annotations

import json
import uuid
from typing import Any
from app.core.settings import settings
from app.models.run_models import (
    AgentProgressStep,
    Finding,
    ScreenReaderResult,
    UsabilityRunRequest,
    UsabilityRunResult,
)
from app.repositories.config_repo import ConfigRepo
from app.repositories.run_repo import RunRepo
from app.services.figma_service import FigmaService
from app.services.knowledge_service import KnowledgeService
from app.services.llm_client import LiteLLMClient, LLMNotConfigured


DISCLAIMER = (
    "This is AI-generated simulated usability feedback. It complements but does not replace "
    "moderated user research, UX researcher judgment, accessibility testing, product review, "
    "legal/compliance review, or clinical review. Figma screen-reader output is inferred from design data; "
    "final accessibility validation must be performed on implemented UI."
)


class UsabilityAgent:
    def __init__(self):
        self.config_repo = ConfigRepo()
        self.knowledge_service = KnowledgeService()
        self.run_repo = RunRepo()
        self.figma = FigmaService()

    async def run(self, request: UsabilityRunRequest) -> UsabilityRunResult:
        run_id = str(uuid.uuid4())
        progress = self._initial_progress()
        raw_outputs: dict[str, Any] = {}

        product = self.config_repo.get_config("product", request.product_id)
        if not product:
            raise ValueError(f"Product config not found in DynamoDB: {request.product_id}")
        journey = None
        if request.journey_id:
            journey = self.config_repo.get_config("journey", request.journey_id, parent_id=request.product_id)

        personas = self._load_personas(request, product)
        risk_checklists = self._load_risk_checklists(product, journey)
        prompt_templates = self._load_prompt_templates()

        screen_reader = await self._screen_reader(request, progress, raw_outputs)
        knowledge_chunks = self._retrieve_knowledge(request, screen_reader, progress, raw_outputs)

        llm_available = settings.litellm_configured()
        if not llm_available:
            result = self._fallback_result(run_id, request, progress, screen_reader, knowledge_chunks)
            self.run_repo.put_run(run_id, request.model_dump(), result.model_dump())
            return result

        llm = LiteLLMClient()
        agent_context = {
            "product": product,
            "journey": journey,
            "screen_name": request.screen_name,
            "device_target": request.device_target,
            "user_flow_context": request.user_flow_context,
            "screen_reader": screen_reader.model_dump(),
            "screen_text": request.screen_text,
            "known_constraints": request.known_constraints,
            "personas": personas,
            "risk_checklists": risk_checklists,
            "knowledge_chunks": knowledge_chunks,
        }

        ux = await self._run_llm_agent(llm, prompt_templates, "ux_heuristics", agent_context, progress, raw_outputs)
        accessibility = await self._run_llm_agent(llm, prompt_templates, "accessibility", agent_context, progress, raw_outputs)
        persona_feedback = await self._run_llm_agent(llm, prompt_templates, "persona_simulation", agent_context, progress, raw_outputs)
        knowledge_synthesis = await self._run_llm_agent(llm, prompt_templates, "knowledge_synthesis", agent_context, progress, raw_outputs)

        final_context = {
            **agent_context,
            "ux_heuristics": ux,
            "accessibility": accessibility,
            "persona_feedback": persona_feedback,
            "knowledge_synthesis": knowledge_synthesis,
        }
        final = await self._run_llm_agent(llm, prompt_templates, "final_synthesis", final_context, progress, raw_outputs)

        findings = self._normalize_findings(final)
        result = UsabilityRunResult(
            run_id=run_id,
            product_id=request.product_id,
            journey_id=request.journey_id,
            screen_name=request.screen_name,
            executive_summary=final.get("executive_summary", "Usability review completed."),
            readiness=final.get("readiness", "Needs UX refinement"),
            progress=progress,
            screen_reader=screen_reader,
            findings=findings,
            persona_feedback=persona_feedback.get("persona_feedback", []) if isinstance(persona_feedback, dict) else [],
            knowledge_used=[
                {"source_id": k.get("source_id"), "source_title": k.get("source_title"), "chunk_index": k.get("chunk_index"), "score": k.get("score")}
                for k in knowledge_chunks
            ],
            raw_agent_outputs=raw_outputs,
            disclaimer=DISCLAIMER,
        )
        self.run_repo.put_run(run_id, request.model_dump(), result.model_dump())
        return result

    def _initial_progress(self) -> list[AgentProgressStep]:
        return [
            AgentProgressStep(step_id="screen_reader", label="Figma Screen Reader", detail="Extract reading order and UI semantics"),
            AgentProgressStep(step_id="knowledge", label="Supplemental Knowledge", detail="Retrieve uploaded value proposition and evidence"),
            AgentProgressStep(step_id="ux_heuristics", label="UX Heuristics", detail="Task clarity, hierarchy, and usability review"),
            AgentProgressStep(step_id="accessibility", label="Accessibility", detail="WCAG-oriented simulated review"),
            AgentProgressStep(step_id="persona_simulation", label="Persona Agents", detail="Configured and on-demand persona feedback"),
            AgentProgressStep(step_id="knowledge_synthesis", label="Evidence Synthesis", detail="Apply knowledge base to findings"),
            AgentProgressStep(step_id="final_synthesis", label="Synthesis", detail="Prioritized report"),
        ]

    def _mark(self, progress: list[AgentProgressStep], step_id: str, status: str, detail: str | None = None):
        for step in progress:
            if step.step_id == step_id:
                step.status = status
                if detail is not None:
                    step.detail = detail
                return

    async def _screen_reader(self, request: UsabilityRunRequest, progress, raw_outputs) -> ScreenReaderResult:
        self._mark(progress, "screen_reader", "running")
        if request.figma_url:
            try:
                payload = await self.figma.fetch_file_or_node(request.figma_url, request.figma_node_id)
                raw_outputs["figma_payload_summary"] = {"keys": list(payload.keys())}
                result = self.figma.build_screen_reader_result(payload)
                if request.screen_text:
                    result.raw_extracted_text += "\n\nAdditional screen text supplied by user:\n" + request.screen_text
                self._mark(progress, "screen_reader", "completed", f"Extracted {len(result.reading_order)} readable items")
                return result
            except Exception as exc:
                self._mark(progress, "screen_reader", "failed", str(exc))
        fallback = ScreenReaderResult(
            source="manual_context",
            reading_order=[line.strip() for line in request.screen_text.splitlines() if line.strip()],
            inferred_roles=[],
            hierarchy_notes=["Figma extraction unavailable. Used manually provided screen text."],
            raw_extracted_text=request.screen_text or request.user_flow_context,
        )
        return fallback

    def _retrieve_knowledge(self, request: UsabilityRunRequest, screen_reader: ScreenReaderResult, progress, raw_outputs) -> list[dict[str, Any]]:
        self._mark(progress, "knowledge", "running")
        query = "\n".join([
            request.screen_name,
            request.user_flow_context,
            screen_reader.raw_extracted_text,
            " ".join(request.known_constraints),
        ])
        chunks = self.knowledge_service.search(
            query=query,
            source_ids=request.knowledge_source_ids,
            product_id=request.product_id,
            journey_id=request.journey_id,
            limit=10,
        )
        raw_outputs["knowledge_retrieval"] = {"count": len(chunks)}
        self._mark(progress, "knowledge", "completed", f"Retrieved {len(chunks)} relevant knowledge chunks")
        return chunks

    def _load_personas(self, request: UsabilityRunRequest, product: dict[str, Any]) -> list[dict[str, Any]]:
        ids = request.selected_persona_ids or product.get("default_persona_ids", [])
        personas = []
        for pid in ids:
            persona = self.config_repo.get_config("persona", pid)
            if persona:
                personas.append(persona)
        return personas

    def _load_risk_checklists(self, product: dict[str, Any], journey: dict[str, Any] | None) -> list[dict[str, Any]]:
        ids = list(product.get("default_risk_checklist_ids", []))
        if journey:
            ids.extend(journey.get("risk_checklist_ids", []))
        unique = []
        for cid in ids:
            if cid not in unique:
                unique.append(cid)
        checklists = []
        for cid in unique:
            checklist = self.config_repo.get_config("risk_checklist", cid)
            if checklist:
                checklists.append(checklist)
        return checklists

    def _load_prompt_templates(self) -> dict[str, dict[str, Any]]:
        templates = {}
        for agent_type in ["ux_heuristics", "accessibility", "persona_simulation", "knowledge_synthesis", "final_synthesis"]:
            template = self.config_repo.get_active_prompt_by_agent_type(agent_type)
            if template:
                templates[agent_type] = template
        return templates

    async def _run_llm_agent(self, llm: LiteLLMClient, templates: dict[str, dict[str, Any]], agent_type: str, context: dict[str, Any], progress, raw_outputs) -> dict[str, Any]:
        self._mark(progress, agent_type, "running")
        template = templates.get(agent_type)
        if not template:
            self._mark(progress, agent_type, "failed", "Prompt template missing in DynamoDB")
            return {"error": f"Missing prompt template for {agent_type}"}
        user_prompt = template["user_prompt_template"].format(context=json.dumps(context, indent=2, default=str))
        try:
            result = await llm.chat_json([
                {"role": "system", "content": template["system_prompt"]},
                {"role": "user", "content": user_prompt},
            ], max_tokens=3500)
            raw_outputs[agent_type] = result
            self._mark(progress, agent_type, "completed")
            return result
        except Exception as exc:
            self._mark(progress, agent_type, "failed", str(exc))
            return {"error": str(exc)}

    def _normalize_findings(self, final: dict[str, Any]) -> list[Finding]:
        items = final.get("findings", []) if isinstance(final, dict) else []
        findings = []
        for idx, item in enumerate(items):
            severity = item.get("severity", "Medium")
            priority = {"Low": 1, "Medium": 2, "High": 4, "Critical": 6}.get(severity, 2)
            if item.get("human_review_flags"):
                priority += 1
            if item.get("evidence"):
                priority += 1
            findings.append(Finding(
                title=item.get("title", f"Finding {idx+1}"),
                category=item.get("category", "Usability"),
                severity=severity,
                observation=item.get("observation", ""),
                member_impact=item.get("member_impact", ""),
                recommendation=item.get("recommendation", ""),
                evidence=item.get("evidence", []),
                impacted_personas=item.get("impacted_personas", []),
                human_review_flags=item.get("human_review_flags", []),
                priority_score=item.get("priority_score", priority),
            ))
        return sorted(findings, key=lambda x: x.priority_score, reverse=True)

    def _fallback_result(self, run_id, request, progress, screen_reader, chunks) -> UsabilityRunResult:
        return UsabilityRunResult(
            run_id=run_id,
            product_id=request.product_id,
            journey_id=request.journey_id,
            screen_name=request.screen_name,
            executive_summary="LiteLLM is not configured. Figma/manual screen-reader extraction and knowledge retrieval completed, but AI usability synthesis was skipped.",
            readiness="Needs UX refinement",
            progress=progress,
            screen_reader=screen_reader,
            findings=[],
            persona_feedback=[],
            knowledge_used=[{"source_id": c.get("source_id"), "source_title": c.get("source_title"), "chunk_index": c.get("chunk_index")} for c in chunks],
            raw_agent_outputs={},
            disclaimer=DISCLAIMER,
        )
