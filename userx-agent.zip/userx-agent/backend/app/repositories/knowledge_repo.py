from __future__ import annotations

from typing import Any
from app.repositories.base_repo import BaseRepo


class KnowledgeRepo(BaseRepo):
    def put_source(self, source_id: str, source: dict[str, Any]) -> dict[str, Any]:
        return self.put({
            "PK": "KNOWLEDGE#SOURCE",
            "SK": f"SOURCE#{source_id}",
            "GSI1PK": "ENTITY#KNOWLEDGE_SOURCE",
            "GSI1SK": source_id,
            "entity_type": "KNOWLEDGE_SOURCE",
            "source_id": source_id,
            "data": source,
        })

    def put_chunk(self, source_id: str, chunk_index: int, chunk: dict[str, Any]) -> dict[str, Any]:
        return self.put({
            "PK": f"KNOWLEDGE#{source_id}",
            "SK": f"CHUNK#{chunk_index:04d}",
            "GSI1PK": "ENTITY#KNOWLEDGE_CHUNK",
            "GSI1SK": f"{source_id}#{chunk_index:04d}",
            "entity_type": "KNOWLEDGE_CHUNK",
            "source_id": source_id,
            "chunk_index": chunk_index,
            "data": chunk,
        })

    def list_sources(self) -> list[dict[str, Any]]:
        return [item.get("data", {}) for item in self.query_pk("KNOWLEDGE#SOURCE")]

    def get_source(self, source_id: str) -> dict[str, Any] | None:
        item = self.get("KNOWLEDGE#SOURCE", f"SOURCE#{source_id}")
        return item.get("data") if item else None

    def list_chunks(self, source_id: str) -> list[dict[str, Any]]:
        return [item.get("data", {}) for item in self.query_pk(f"KNOWLEDGE#{source_id}")]
