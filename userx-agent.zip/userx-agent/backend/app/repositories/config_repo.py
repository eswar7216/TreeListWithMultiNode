from __future__ import annotations

from typing import Any
from app.repositories.base_repo import BaseRepo


class ConfigRepo(BaseRepo):
    ENTITY_TO_KEYS = {
        "product": ("CONFIG#PRODUCT", "PRODUCT#", "PRODUCT_CONFIG"),
        "journey": ("CONFIG#JOURNEY", "JOURNEY#", "JOURNEY_CONFIG"),
        "persona": ("CONFIG#PERSONA", "PERSONA#", "PERSONA_CONFIG"),
        "risk_checklist": ("CONFIG#RISK_CHECKLIST", "RISK#", "RISK_CHECKLIST"),
        "prompt_template": ("CONFIG#PROMPT_TEMPLATE", "PROMPT#", "PROMPT_TEMPLATE"),
    }

    def put_config(self, config_type: str, config_id: str, data: dict[str, Any], parent_id: str | None = None) -> dict[str, Any]:
        base_pk, sk_prefix, entity_type = self.ENTITY_TO_KEYS[config_type]
        pk = base_pk if not parent_id else f"{base_pk}#{parent_id}"
        item = {
            "PK": pk,
            "SK": f"{sk_prefix}{config_id}",
            "GSI1PK": f"ENTITY#{entity_type}",
            "GSI1SK": config_id,
            "entity_type": entity_type,
            "config_type": config_type,
            "config_id": config_id,
            "parent_id": parent_id or "",
            "data": data,
        }
        return self.put(item)

    def list_configs(self, config_type: str, parent_id: str | None = None) -> list[dict[str, Any]]:
        base_pk, _, _ = self.ENTITY_TO_KEYS[config_type]
        pk = base_pk if not parent_id else f"{base_pk}#{parent_id}"
        return [item.get("data", {}) for item in self.query_pk(pk)]

    def get_config(self, config_type: str, config_id: str, parent_id: str | None = None) -> dict[str, Any] | None:
        base_pk, sk_prefix, _ = self.ENTITY_TO_KEYS[config_type]
        pk = base_pk if not parent_id else f"{base_pk}#{parent_id}"
        item = self.get(pk, f"{sk_prefix}{config_id}")
        return item.get("data") if item else None

    def delete_config(self, config_type: str, config_id: str, parent_id: str | None = None) -> None:
        base_pk, sk_prefix, _ = self.ENTITY_TO_KEYS[config_type]
        pk = base_pk if not parent_id else f"{base_pk}#{parent_id}"
        self.delete(pk, f"{sk_prefix}{config_id}")

    def list_all_prompt_templates(self) -> list[dict[str, Any]]:
        return self.list_configs("prompt_template")

    def get_active_prompt_by_agent_type(self, agent_type: str) -> dict[str, Any] | None:
        templates = self.list_all_prompt_templates()
        active = [t for t in templates if t.get("agent_type") == agent_type and t.get("is_active", True)]
        if not active:
            return None
        return sorted(active, key=lambda x: x.get("version", "0"), reverse=True)[0]
