from __future__ import annotations

from typing import Any
from app.repositories.base_repo import BaseRepo


class RunRepo(BaseRepo):
    def put_run(self, run_id: str, request: dict[str, Any], result: dict[str, Any]) -> dict[str, Any]:
        return self.put({
            "PK": f"RUN#{run_id}",
            "SK": "METADATA",
            "GSI1PK": "ENTITY#AGENT_RUN",
            "GSI1SK": run_id,
            "entity_type": "AGENT_RUN",
            "run_id": run_id,
            "request": request,
            "result": result,
        })

    def get_run(self, run_id: str) -> dict[str, Any] | None:
        item = self.get(f"RUN#{run_id}", "METADATA")
        return item

    def list_runs(self) -> list[dict[str, Any]]:
        return self.scan_entity("AGENT_RUN")
