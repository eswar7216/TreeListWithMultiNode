from __future__ import annotations

from datetime import datetime, timezone
from typing import Any
from boto3.dynamodb.conditions import Key
from app.db.dynamodb import table


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


class BaseRepo:
    def __init__(self):
        self.table = table()

    def put(self, item: dict[str, Any]) -> dict[str, Any]:
        item.setdefault("created_at", now_iso())
        item["updated_at"] = now_iso()
        self.table.put_item(Item=item)
        return item

    def get(self, pk: str, sk: str) -> dict[str, Any] | None:
        resp = self.table.get_item(Key={"PK": pk, "SK": sk})
        return resp.get("Item")

    def query_pk(self, pk: str) -> list[dict[str, Any]]:
        resp = self.table.query(KeyConditionExpression=Key("PK").eq(pk))
        return resp.get("Items", [])

    def delete(self, pk: str, sk: str) -> None:
        self.table.delete_item(Key={"PK": pk, "SK": sk})

    def scan_entity(self, entity_type: str) -> list[dict[str, Any]]:
        resp = self.table.scan(
            FilterExpression="entity_type = :entity_type",
            ExpressionAttributeValues={":entity_type": entity_type},
        )
        items = resp.get("Items", [])
        while "LastEvaluatedKey" in resp:
            resp = self.table.scan(
                FilterExpression="entity_type = :entity_type",
                ExpressionAttributeValues={":entity_type": entity_type},
                ExclusiveStartKey=resp["LastEvaluatedKey"],
            )
            items.extend(resp.get("Items", []))
        return items
