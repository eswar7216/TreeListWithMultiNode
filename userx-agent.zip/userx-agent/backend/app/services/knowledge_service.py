from __future__ import annotations

import re
import uuid
from datetime import datetime, timezone
from app.repositories.knowledge_repo import KnowledgeRepo
from app.services.document_service import extract_text_from_file, chunk_text


class KnowledgeService:
    def __init__(self):
        self.repo = KnowledgeRepo()

    def ingest_upload(self, filename: str, data: bytes, title: str, product_ids: list[str], journey_ids: list[str], tags: list[str]) -> dict:
        source_id = str(uuid.uuid4())
        text = extract_text_from_file(filename, data)
        chunks = chunk_text(text)
        source = {
            "source_id": source_id,
            "title": title or filename,
            "source_type": "uploaded_supplemental_knowledge",
            "file_name": filename,
            "product_ids": product_ids,
            "journey_ids": journey_ids,
            "tags": tags,
            "summary": text[:1000],
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
        self.repo.put_source(source_id, source)
        for idx, chunk in enumerate(chunks):
            self.repo.put_chunk(source_id, idx, {
                "source_id": source_id,
                "chunk_id": f"{source_id}:{idx}",
                "chunk_index": idx,
                "text": chunk,
                "tags": tags,
            })
        return {**source, "chunk_count": len(chunks)}

    def search(self, query: str, source_ids: list[str] | None = None, product_id: str | None = None, journey_id: str | None = None, limit: int = 8) -> list[dict]:
        sources = self.repo.list_sources()
        if source_ids:
            sources = [s for s in sources if s.get("source_id") in source_ids]
        if product_id:
            sources = [s for s in sources if not s.get("product_ids") or product_id in s.get("product_ids", [])]
        if journey_id:
            sources = [s for s in sources if not s.get("journey_ids") or journey_id in s.get("journey_ids", [])]

        terms = [t.lower() for t in re.findall(r"[a-zA-Z0-9$%]+", query or "") if len(t) > 2]
        results = []
        for source in sources:
            chunks = self.repo.list_chunks(source["source_id"])
            for chunk in chunks:
                text = chunk.get("text", "")
                low = text.lower()
                score = sum(low.count(term) for term in terms)
                tag_score = sum(2 for tag in source.get("tags", []) if tag.lower() in terms)
                score += tag_score
                if score > 0 or not terms:
                    results.append({
                        "source_id": source["source_id"],
                        "source_title": source.get("title"),
                        "chunk_index": chunk.get("chunk_index"),
                        "text": text,
                        "score": score,
                        "tags": source.get("tags", []),
                    })
        return sorted(results, key=lambda x: x["score"], reverse=True)[:limit]
