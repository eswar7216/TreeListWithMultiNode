from __future__ import annotations

from io import BytesIO
from pathlib import Path
from typing import Iterable
from docx import Document
from pypdf import PdfReader
from pptx import Presentation


def extract_text_from_file(filename: str, data: bytes) -> str:
    suffix = Path(filename).suffix.lower()
    if suffix in {".txt", ".md", ".csv", ".html", ".htm"}:
        return data.decode("utf-8", errors="ignore")
    if suffix == ".pdf":
        reader = PdfReader(BytesIO(data))
        return "\n".join(page.extract_text() or "" for page in reader.pages)
    if suffix == ".docx":
        doc = Document(BytesIO(data))
        return "\n".join(p.text for p in doc.paragraphs)
    if suffix == ".pptx":
        prs = Presentation(BytesIO(data))
        chunks = []
        for i, slide in enumerate(prs.slides, start=1):
            chunks.append(f"Slide {i}")
            for shape in slide.shapes:
                if hasattr(shape, "text"):
                    text = shape.text.strip()
                    if text:
                        chunks.append(text)
        return "\n".join(chunks)
    return data.decode("utf-8", errors="ignore")


def chunk_text(text: str, chunk_size: int = 1500, overlap: int = 200) -> list[str]:
    cleaned = "\n".join(line.strip() for line in text.splitlines() if line.strip())
    if not cleaned:
        return []
    chunks = []
    start = 0
    while start < len(cleaned):
        end = start + chunk_size
        chunks.append(cleaned[start:end])
        start = max(end - overlap, end)
    return chunks
