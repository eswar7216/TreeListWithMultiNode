from __future__ import annotations

import re
from typing import Any
import httpx
from app.core.settings import settings
from app.models.run_models import ScreenReaderResult


FIGMA_FILE_RE = re.compile(r"figma\.com/(?:file|design)/([A-Za-z0-9]+)")
FIGMA_NODE_RE = re.compile(r"node-id=([^&]+)")


def parse_figma_url(url: str) -> tuple[str | None, str | None]:
    file_match = FIGMA_FILE_RE.search(url or "")
    node_match = FIGMA_NODE_RE.search(url or "")
    file_key = file_match.group(1) if file_match else None
    node_id = None
    if node_match:
        node_id = node_match.group(1).replace("-", ":")
    return file_key, node_id


class FigmaService:
    async def fetch_file_or_node(self, figma_url: str, explicit_node_id: str | None = None) -> dict[str, Any]:
        file_key, parsed_node_id = parse_figma_url(figma_url)
        node_id = explicit_node_id or parsed_node_id
        if not file_key:
            raise ValueError("Could not parse Figma file key from URL.")
        if not settings.figma_configured():
            raise RuntimeError("Figma token is not configured. Set FIGMA_ACCESS_TOKEN.")

        headers = {"X-Figma-Token": settings.figma_access_token}
        async with httpx.AsyncClient(timeout=60.0) as client:
            if node_id:
                resp = await client.get(
                    f"https://api.figma.com/v1/files/{file_key}/nodes",
                    params={"ids": node_id},
                    headers=headers,
                )
            else:
                resp = await client.get(
                    f"https://api.figma.com/v1/files/{file_key}",
                    headers=headers,
                )
            resp.raise_for_status()
            return resp.json()

    def build_screen_reader_result(self, figma_payload: dict[str, Any]) -> ScreenReaderResult:
        nodes: list[dict[str, Any]] = []

        def walk(node: dict[str, Any], depth: int = 0):
            if not isinstance(node, dict):
                return
            item = {
                "name": node.get("name", ""),
                "type": node.get("type", ""),
                "characters": node.get("characters", ""),
                "depth": depth,
                "absoluteBoundingBox": node.get("absoluteBoundingBox") or {},
            }
            if item["characters"] or item["name"]:
                nodes.append(item)
            for child in node.get("children", []) or []:
                walk(child, depth + 1)

        if "nodes" in figma_payload:
            for wrapper in figma_payload["nodes"].values():
                walk(wrapper.get("document", {}))
        else:
            walk(figma_payload.get("document", {}))

        def sort_key(item):
            box = item.get("absoluteBoundingBox") or {}
            return (box.get("y", 0), box.get("x", 0), item.get("depth", 0))

        readable = []
        inferred_roles = []
        for item in sorted(nodes, key=sort_key):
            text = item.get("characters") or item.get("name") or ""
            text = " ".join(str(text).split())
            if not text or text.lower() in {"frame", "group"}:
                continue
            role = self._infer_role(text, item.get("type", ""))
            readable.append(text)
            inferred_roles.append({"text": text, "role": role})

        return ScreenReaderResult(
            source="figma",
            reading_order=readable[:250],
            inferred_roles=inferred_roles[:250],
            hierarchy_notes=[
                "Reading order is inferred from Figma layer position: top-to-bottom, left-to-right.",
                "This simulates screen-reader review from design structure, but final validation requires implemented DOM accessibility testing.",
            ],
            raw_extracted_text="\n".join(readable[:500]),
        )

    def _infer_role(self, text: str, figma_type: str) -> str:
        low = text.lower()
        if any(x in low for x in ["continue", "submit", "save", "download", "get started", "search", "next"]):
            return "button_or_cta"
        if low.startswith(("1.", "2.", "3.", "step")):
            return "step_or_instruction"
        if figma_type == "TEXT" and len(text) < 60:
            return "heading_or_label"
        if "$" in text or "cost" in low or "price" in low:
            return "cost_or_price_text"
        return "text"
