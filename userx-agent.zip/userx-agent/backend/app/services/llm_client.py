from __future__ import annotations

from typing import Any
import httpx
from app.core.settings import settings


class LLMNotConfigured(RuntimeError):
    pass


class LiteLLMClient:
    def __init__(self, model: str | None = None):
        if not settings.litellm_configured():
            raise LLMNotConfigured("LiteLLM is not configured. Set LITELLM_API_BASE and LITELLM_API_KEY.")
        self.base_url = settings.litellm_api_base.rstrip("/")
        self.api_key = settings.litellm_api_key
        self.model = model or settings.litellm_model

    async def chat_json(self, messages: list[dict[str, Any]], max_tokens: int = 3000, temperature: float = 0.1) -> dict[str, Any]:
        payload = {
            "model": self.model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "response_format": {"type": "json_object"},
        }
        async with httpx.AsyncClient(timeout=90.0) as client:
            resp = await client.post(
                f"{self.base_url}/chat/completions",
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json",
                    "Accept": "application/json",
                },
                json=payload,
            )
            resp.raise_for_status()
            data = resp.json()
            content = data["choices"][0]["message"]["content"]
        return self._safe_json(content)

    def _safe_json(self, content: str) -> dict[str, Any]:
        import json
        text = content.strip()
        if text.startswith("```"):
            text = text.strip("`").strip()
            if text.startswith("json"):
                text = text[4:].strip()
        start = text.find("{")
        end = text.rfind("}")
        if start >= 0 and end >= 0:
            text = text[start:end+1]
        return json.loads(text)
