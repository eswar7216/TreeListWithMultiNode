from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api.routes_configs import router as configs_router
from app.api.routes_knowledge import router as knowledge_router
from app.api.routes_runs import router as runs_router
from app.db.dynamodb import ensure_table_exists

app = FastAPI(title="UserX Agent API", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def startup():
    ensure_table_exists()


@app.get("/health")
def health():
    return {"status": "ok"}


app.include_router(configs_router, prefix="/api")
app.include_router(knowledge_router, prefix="/api")
app.include_router(runs_router, prefix="/api")
