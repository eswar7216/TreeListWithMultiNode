from __future__ import annotations

from typing import Any, Literal
from pydantic import BaseModel, Field


class UploadedKnowledgeRef(BaseModel):
    source_id: str
    title: str


class UsabilityRunRequest(BaseModel):
    product_id: str
    journey_id: str | None = None
    screen_name: str
    figma_url: str | None = None
    figma_node_id: str | None = None
    device_target: Literal["desktop", "mobile", "tablet"] = "desktop"
    user_flow_context: str = ""
    screen_text: str = ""
    selected_persona_ids: list[str] = Field(default_factory=list)
    knowledge_source_ids: list[str] = Field(default_factory=list)
    known_constraints: list[str] = Field(default_factory=list)
    run_options: dict[str, Any] = Field(default_factory=dict)


class AgentProgressStep(BaseModel):
    step_id: str
    label: str
    status: Literal["pending", "running", "completed", "failed"] = "pending"
    detail: str = ""


class Finding(BaseModel):
    title: str
    category: str
    severity: Literal["Low", "Medium", "High", "Critical"]
    observation: str
    member_impact: str
    recommendation: str
    evidence: list[str] = Field(default_factory=list)
    impacted_personas: list[str] = Field(default_factory=list)
    human_review_flags: list[str] = Field(default_factory=list)
    priority_score: int = 0


class ScreenReaderResult(BaseModel):
    source: str
    reading_order: list[str] = Field(default_factory=list)
    inferred_roles: list[dict[str, str]] = Field(default_factory=list)
    hierarchy_notes: list[str] = Field(default_factory=list)
    raw_extracted_text: str = ""


class UsabilityRunResult(BaseModel):
    run_id: str
    product_id: str
    journey_id: str | None = None
    screen_name: str
    executive_summary: str
    readiness: Literal[
        "Ready",
        "Proceed with minor refinements",
        "Needs UX refinement",
        "Formal research recommended"
    ]
    progress: list[AgentProgressStep]
    screen_reader: ScreenReaderResult
    findings: list[Finding]
    persona_feedback: list[dict[str, Any]] = Field(default_factory=list)
    knowledge_used: list[dict[str, Any]] = Field(default_factory=list)
    raw_agent_outputs: dict[str, Any] = Field(default_factory=dict)
    disclaimer: str
