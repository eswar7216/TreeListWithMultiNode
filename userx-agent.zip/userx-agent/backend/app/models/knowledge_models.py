from __future__ import annotations

from pydantic import BaseModel, Field


class KnowledgeSource(BaseModel):
    source_id: str
    title: str
    source_type: str = "uploaded_document"
    product_ids: list[str] = Field(default_factory=list)
    journey_ids: list[str] = Field(default_factory=list)
    tags: list[str] = Field(default_factory=list)
    summary: str = ""
    file_name: str | None = None
    created_at: str | None = None


class KnowledgeChunk(BaseModel):
    source_id: str
    chunk_id: str
    chunk_index: int
    text: str
    tags: list[str] = Field(default_factory=list)


class KnowledgeSearchRequest(BaseModel):
    query: str
    product_id: str | None = None
    journey_id: str | None = None
    source_ids: list[str] = Field(default_factory=list)
    limit: int = 8
