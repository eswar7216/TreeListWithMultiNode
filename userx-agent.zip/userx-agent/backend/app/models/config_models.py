from __future__ import annotations

from typing import Any, Literal
from pydantic import BaseModel, Field


class ProductConfig(BaseModel):
    product_id: str
    name: str
    description: str = ""
    domain: str = ""
    default_journey_id: str | None = None
    default_persona_ids: list[str] = Field(default_factory=list)
    default_risk_checklist_ids: list[str] = Field(default_factory=list)
    default_prompt_template_ids: list[str] = Field(default_factory=list)
    tags: list[str] = Field(default_factory=list)
    is_active: bool = True


class JourneyConfig(BaseModel):
    journey_id: str
    product_id: str
    name: str
    user_goal: str = ""
    business_goal: str = ""
    expected_user_action: str = ""
    known_confusion_points: list[str] = Field(default_factory=list)
    risk_checklist_ids: list[str] = Field(default_factory=list)
    tags: list[str] = Field(default_factory=list)
    is_active: bool = True


class PersonaConfig(BaseModel):
    persona_id: str
    name: str
    description: str = ""
    tags: list[str] = Field(default_factory=list)
    attributes: dict[str, Any] = Field(default_factory=dict)
    goals: list[str] = Field(default_factory=list)
    likely_questions: list[str] = Field(default_factory=list)
    likely_friction_points: list[str] = Field(default_factory=list)
    recruiting_value: str = ""
    evidence_source_ids: list[str] = Field(default_factory=list)
    is_active: bool = True


class RiskChecklist(BaseModel):
    checklist_id: str
    name: str
    description: str = ""
    category: str = ""
    review_questions: list[str] = Field(default_factory=list)
    applies_to_tags: list[str] = Field(default_factory=list)
    default_severity: Literal["Low", "Medium", "High", "Critical"] = "Medium"
    requires_review_roles: list[str] = Field(default_factory=list)
    is_active: bool = True


class PromptTemplate(BaseModel):
    template_id: str
    name: str
    agent_type: Literal[
        "screen_reader",
        "ux_heuristics",
        "accessibility",
        "persona_simulation",
        "knowledge_synthesis",
        "final_synthesis"
    ]
    version: str = "1.0.0"
    system_prompt: str
    user_prompt_template: str
    expected_json_schema: dict[str, Any] = Field(default_factory=dict)
    is_active: bool = True


class ConfigListResponse(BaseModel):
    items: list[dict[str, Any]]
