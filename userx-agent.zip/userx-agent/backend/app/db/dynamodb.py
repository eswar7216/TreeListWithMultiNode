from __future__ import annotations

import boto3
from botocore.exceptions import ClientError
from app.core.settings import settings


def dynamodb_resource():
    kwargs = {
        "region_name": settings.aws_region,
        "aws_access_key_id": "local",
        "aws_secret_access_key": "local",
    }
    if settings.dynamodb_endpoint_url:
        kwargs["endpoint_url"] = settings.dynamodb_endpoint_url
    return boto3.resource("dynamodb", **kwargs)


def dynamodb_client():
    kwargs = {
        "region_name": settings.aws_region,
        "aws_access_key_id": "local",
        "aws_secret_access_key": "local",
    }
    if settings.dynamodb_endpoint_url:
        kwargs["endpoint_url"] = settings.dynamodb_endpoint_url
    return boto3.client("dynamodb", **kwargs)


def table():
    return dynamodb_resource().Table(settings.dynamodb_table_name)


def ensure_table_exists() -> None:
    client = dynamodb_client()
    try:
        client.describe_table(TableName=settings.dynamodb_table_name)
        return
    except ClientError as exc:
        if exc.response.get("Error", {}).get("Code") != "ResourceNotFoundException":
            raise

    client.create_table(
        TableName=settings.dynamodb_table_name,
        BillingMode="PAY_PER_REQUEST",
        AttributeDefinitions=[
            {"AttributeName": "PK", "AttributeType": "S"},
            {"AttributeName": "SK", "AttributeType": "S"},
            {"AttributeName": "GSI1PK", "AttributeType": "S"},
            {"AttributeName": "GSI1SK", "AttributeType": "S"},
        ],
        KeySchema=[
            {"AttributeName": "PK", "KeyType": "HASH"},
            {"AttributeName": "SK", "KeyType": "RANGE"},
        ],
        GlobalSecondaryIndexes=[
            {
                "IndexName": "GSI1",
                "KeySchema": [
                    {"AttributeName": "GSI1PK", "KeyType": "HASH"},
                    {"AttributeName": "GSI1SK", "KeyType": "RANGE"},
                ],
                "Projection": {"ProjectionType": "ALL"},
            }
        ],
    )
    waiter = client.get_waiter("table_exists")
    waiter.wait(TableName=settings.dynamodb_table_name)
