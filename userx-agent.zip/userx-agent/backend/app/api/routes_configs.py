from __future__ import annotations

from fastapi import APIRouter, HTTPException, Query
from app.repositories.config_repo import ConfigRepo

router = APIRouter(prefix="/configs", tags=["configs"])
repo = ConfigRepo()

VALID_TYPES = {"product", "journey", "persona", "risk_checklist", "prompt_template"}


@router.get("/{config_type}")
def list_configs(config_type: str, parent_id: str | None = Query(None)):
    if config_type not in VALID_TYPES:
        raise HTTPException(400, "Invalid config type")
    return {"items": repo.list_configs(config_type, parent_id)}


@router.get("/{config_type}/{config_id}")
def get_config(config_type: str, config_id: str, parent_id: str | None = Query(None)):
    if config_type not in VALID_TYPES:
        raise HTTPException(400, "Invalid config type")
    item = repo.get_config(config_type, config_id, parent_id)
    if not item:
        raise HTTPException(404, "Config not found")
    return item


@router.put("/{config_type}/{config_id}")
def put_config(config_type: str, config_id: str, payload: dict, parent_id: str | None = Query(None)):
    if config_type not in VALID_TYPES:
        raise HTTPException(400, "Invalid config type")
    saved = repo.put_config(config_type, config_id, payload, parent_id)
    return saved.get("data", payload)


@router.delete("/{config_type}/{config_id}")
def delete_config(config_type: str, config_id: str, parent_id: str | None = Query(None)):
    if config_type not in VALID_TYPES:
        raise HTTPException(400, "Invalid config type")
    repo.delete_config(config_type, config_id, parent_id)
    return {"deleted": True}
