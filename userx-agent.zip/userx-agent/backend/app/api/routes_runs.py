from __future__ import annotations

from fastapi import APIRouter
from app.agents.usability_agent import UsabilityAgent
from app.models.run_models import UsabilityRunRequest
from app.repositories.run_repo import RunRepo

router = APIRouter(prefix="/runs", tags=["usability runs"])
agent = UsabilityAgent()
repo = RunRepo()


@router.post("/usability")
async def run_usability(request: UsabilityRunRequest):
    return await agent.run(request)


@router.get("")
def list_runs():
    return {"items": repo.list_runs()}


@router.get("/{run_id}")
def get_run(run_id: str):
    return repo.get_run(run_id)
