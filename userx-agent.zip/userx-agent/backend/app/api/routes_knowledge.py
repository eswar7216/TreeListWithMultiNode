from __future__ import annotations

from fastapi import APIRouter, File, Form, UploadFile
from app.services.knowledge_service import KnowledgeService
from app.repositories.knowledge_repo import KnowledgeRepo

router = APIRouter(prefix="/knowledge", tags=["knowledge"])
service = KnowledgeService()
repo = KnowledgeRepo()


def split_csv(value: str | None) -> list[str]:
    return [v.strip() for v in (value or "").split(",") if v.strip()]


@router.get("/sources")
def list_sources():
    return {"items": repo.list_sources()}


@router.post("/upload")
async def upload_knowledge(
    file: UploadFile = File(...),
    title: str = Form(""),
    product_ids: str = Form(""),
    journey_ids: str = Form(""),
    tags: str = Form(""),
):
    data = await file.read()
    result = service.ingest_upload(
        filename=file.filename or "uploaded-file",
        data=data,
        title=title or file.filename or "Uploaded knowledge",
        product_ids=split_csv(product_ids),
        journey_ids=split_csv(journey_ids),
        tags=split_csv(tags),
    )
    return result


@router.get("/sources/{source_id}/chunks")
def list_chunks(source_id: str):
    return {"items": repo.list_chunks(source_id)}
