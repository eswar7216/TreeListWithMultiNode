from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    dynamodb_endpoint_url: str | None = None
    dynamodb_table_name: str = "UserXAgentLocal"
    aws_region: str = "us-east-1"
    litellm_api_base: str | None = None
    litellm_api_key: str | None = None
    litellm_model: str = "gpt-4o-mini"
    figma_access_token: str | None = None

    class Config:
        env_file = ".env"
        extra = "ignore"

    def litellm_configured(self) -> bool:
        return bool(self.litellm_api_base and self.litellm_api_key)

    def figma_configured(self) -> bool:
        return bool(self.figma_access_token)


settings = Settings()
