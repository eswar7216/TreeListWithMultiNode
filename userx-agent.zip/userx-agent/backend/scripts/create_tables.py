from app.db.dynamodb import ensure_table_exists

if __name__ == "__main__":
    ensure_table_exists()
    print("DynamoDB table is ready")
