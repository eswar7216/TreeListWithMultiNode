from app.db.dynamodb import ensure_table_exists
from app.repositories.config_repo import ConfigRepo


def main():
    ensure_table_exists()
    repo = ConfigRepo()

    # Local demo bootstrap only. Runtime application loads these records from DynamoDB.
    product = {
        "product_id": "unified_medication_decision",
        "name": "Unified Medication Decision Experience",
        "description": "Decision-ready PBM experience combining coverage, pricing, pharmacy choice, and next steps.",
        "domain": "PBM Member Experience",
        "default_journey_id": "check_coverage_find_pharmacy",
        "default_persona_ids": ["cost_sensitive_member", "caregiver", "low_health_literacy_member", "senior_low_digital_confidence"],
        "default_risk_checklist_ids": ["coverage_clarity", "pricing_transparency", "pharmacy_choice", "next_steps", "accessibility"],
        "default_prompt_template_ids": ["ux_heuristics_v1", "accessibility_v1", "persona_simulation_v1", "knowledge_synthesis_v1", "final_synthesis_v1"],
        "tags": ["check_coverage", "find_a_pharmacy", "pbm", "member_web"],
        "is_active": True,
    }
    repo.put_config("product", product["product_id"], product)

    journey = {
        "journey_id": "check_coverage_find_pharmacy",
        "product_id": product["product_id"],
        "name": "Check Coverage + Find a Pharmacy",
        "user_goal": "Answer whether the member can get a medication at a given pharmacy for a trusted cost and know what to do next.",
        "business_goal": "Reduce friction and calls by providing one decision-ready experience.",
        "expected_user_action": "Review coverage, cost, pharmacy options, and next steps in one flow.",
        "known_confusion_points": ["Coverage status meaning", "Best price logic", "Preferred or in-network pharmacy meaning", "What to do when not covered or price unavailable"],
        "risk_checklist_ids": ["coverage_clarity", "pricing_transparency", "pharmacy_choice", "next_steps", "accessibility"],
        "tags": ["coverage", "pricing", "pharmacy", "next_steps"],
        "is_active": True,
    }
    repo.put_config("journey", journey["journey_id"], journey, parent_id=product["product_id"])

    personas = [
        {
            "persona_id": "cost_sensitive_member",
            "name": "Cost-Sensitive Member",
            "description": "Member who focuses on out-of-pocket cost and wants confidence that displayed prices are accurate and actionable.",
            "tags": ["cost", "price", "savings", "deductible", "pharmacy"],
            "attributes": {"digital_comfort": "medium", "health_literacy": "medium", "cost_sensitivity": "high", "trust_level": "medium"},
            "goals": ["Understand what they will pay", "Know why the price differs by pharmacy or supply", "Avoid surprise costs"],
            "likely_questions": ["Is this the price I will pay?", "Why is this pharmacy cheaper?", "Does this include my deductible?"],
            "likely_friction_points": ["Distrusts unexplained price differences", "May confuse estimated cost with guaranteed price"],
            "recruiting_value": "Validates pricing transparency and trust.",
            "evidence_source_ids": [],
            "is_active": True,
        },
        {
            "persona_id": "caregiver",
            "name": "Caregiver Managing Prescriptions",
            "description": "Caregiver who manages medication decisions for a spouse, parent, child, or dependent.",
            "tags": ["caregiver", "doctor", "share", "next_steps"],
            "attributes": {"digital_comfort": "medium", "health_literacy": "medium", "cost_sensitivity": "medium", "trust_level": "medium"},
            "goals": ["Know who the medication applies to", "Know what to tell the doctor or pharmacy", "Share clear information"],
            "likely_questions": ["What should I do next?", "Can I send this to the doctor?", "Which pharmacy should I use?"],
            "likely_friction_points": ["Needs clear member identity and handoff steps", "May struggle when coverage and pharmacy details are separated"],
            "recruiting_value": "Validates next-step clarity and handoff experience.",
            "evidence_source_ids": [],
            "is_active": True,
        },
        {
            "persona_id": "low_health_literacy_member",
            "name": "Low Health Literacy Member",
            "description": "Member who may not understand coverage, formulary, network, PA, step therapy, quantity limit, or plan-stage terminology.",
            "tags": ["plain_language", "coverage", "pbm_terms", "education"],
            "attributes": {"digital_comfort": "medium", "health_literacy": "low", "cost_sensitivity": "high", "trust_level": "medium"},
            "goals": ["Understand the coverage result", "Know if action is required", "Avoid backend labels and jargon"],
            "likely_questions": ["What does covered mean?", "Why do I need prior authorization?", "What should I do if this is not covered?"],
            "likely_friction_points": ["Status labels without explanation", "External PDFs instead of inline next steps"],
            "recruiting_value": "Validates plain-language PBM explanation.",
            "evidence_source_ids": [],
            "is_active": True,
        },
        {
            "persona_id": "senior_low_digital_confidence",
            "name": "Senior Member with Lower Digital Confidence",
            "description": "Senior member who needs simple hierarchy, clear actions, readable content, and predictable navigation.",
            "tags": ["accessibility", "low_digital_confidence", "cta", "navigation"],
            "attributes": {"digital_comfort": "low", "health_literacy": "medium", "cost_sensitivity": "medium", "trust_level": "medium"},
            "goals": ["Understand the page purpose", "Avoid unintended action", "Know the next step"],
            "likely_questions": ["What do I click?", "Am I changing anything now?", "Is this pharmacy in network?"],
            "likely_friction_points": ["Dense result pages", "Small text", "Weak CTA labels"],
            "recruiting_value": "Validates accessibility and cognitive load.",
            "evidence_source_ids": [],
            "is_active": True,
        }
    ]
    for p in personas:
        repo.put_config("persona", p["persona_id"], p)

    risks = [
        ("coverage_clarity", "Coverage Clarity", "Does the screen clearly explain covered/not covered, plan rules, limitations, and coverage status meaning?"),
        ("pricing_transparency", "Pricing Transparency", "Does the screen explain estimated vs guaranteed cost, 30/90-day supply, retail vs mail, deductible, plan stage, and pharmacy effects?"),
        ("pharmacy_choice", "Pharmacy Choice", "Does the screen make pharmacy eligibility, preferred status, in-network status, and comparison clear?"),
        ("next_steps", "Actionable Next Steps", "Does the member know how to get the medication, fill at retail, switch to mail, request PA, contact doctor, or recover from errors?"),
        ("accessibility", "Accessibility and Screen Reader", "Does the Figma reading order, hierarchy, labels, contrast risk, and CTA clarity support accessible use?"),
    ]
    for rid, name, desc in risks:
        repo.put_config("risk_checklist", rid, {
            "checklist_id": rid,
            "name": name,
            "description": desc,
            "category": rid,
            "review_questions": [desc, "What could confuse a member?", "What evidence or persona is impacted?", "What concrete change should design make?"],
            "applies_to_tags": [rid],
            "default_severity": "High" if rid in {"coverage_clarity", "pricing_transparency", "next_steps"} else "Medium",
            "requires_review_roles": ["UX", "Product"] + (["Compliance"] if rid in {"coverage_clarity", "pricing_transparency"} else []),
            "is_active": True,
        })

    common_system = """You are UserX Agent, a PBM UX research assistant for member-facing healthcare experiences. Use supplied Figma screen-reader output, personas, risk checklists, and supplemental knowledge. Do not invent real user research. Mark findings as simulated unless directly supported by supplied knowledge. Return valid JSON only."""
    prompts = [
        ("ux_heuristics_v1", "UX Heuristics", "ux_heuristics", "Return {\"findings\":[{\"title\":string,\"category\":string,\"severity\":\"Low|Medium|High|Critical\",\"observation\":string,\"member_impact\":string,\"recommendation\":string,\"evidence\":[string],\"impacted_personas\":[string],\"human_review_flags\":[string]}]}. Context:\n{context}"),
        ("accessibility_v1", "Accessibility", "accessibility", "Review inferred Figma reading order, hierarchy, labels, and accessibility risks. Return {\"findings\":[...same shape...]}. Context:\n{context}"),
        ("persona_simulation_v1", "Persona Simulation", "persona_simulation", "For each supplied persona, simulate likely reaction, questions, friction, and design implications. Return {\"persona_feedback\":[{\"persona_id\":string,\"persona_name\":string,\"likely_reaction\":string,\"likely_questions\":[string],\"likely_friction_points\":[string],\"design_implications\":[string],\"severity\":\"Low|Medium|High|Critical\"}]}. Context:\n{context}"),
        ("knowledge_synthesis_v1", "Knowledge Synthesis", "knowledge_synthesis", "Use the supplemental knowledge chunks to extract evidence-backed constraints, value proposition, design principles, and applicable pain points. Return {\"evidence_summary\":string,\"applicable_guardrails\":[string],\"evidence_points\":[string]}. Context:\n{context}"),
        ("final_synthesis_v1", "Final Synthesis", "final_synthesis", "Synthesize all agent outputs into a prioritized usability testing report. Return {\"executive_summary\":string,\"readiness\":\"Ready|Proceed with minor refinements|Needs UX refinement|Formal research recommended\",\"findings\":[{\"title\":string,\"category\":string,\"severity\":\"Low|Medium|High|Critical\",\"observation\":string,\"member_impact\":string,\"recommendation\":string,\"evidence\":[string],\"impacted_personas\":[string],\"human_review_flags\":[string],\"priority_score\":number}]}. Context:\n{context}"),
    ]
    for tid, name, agent_type, user_template in prompts:
        repo.put_config("prompt_template", tid, {
            "template_id": tid,
            "name": name,
            "agent_type": agent_type,
            "version": "1.0.0",
            "system_prompt": common_system,
            "user_prompt_template": user_template,
            "expected_json_schema": {},
            "is_active": True,
        })
    print("Demo configuration written to DynamoDB")

if __name__ == "__main__":
    main()
