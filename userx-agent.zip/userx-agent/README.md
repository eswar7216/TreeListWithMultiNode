# UserX Agent — Figma Screen Reader Usability Testing Platform

A local, Dockerized prototype for a configurable **UserX Agent** that reviews Figma prototypes with a screen-reader-style extraction, runs broad usability testing, simulates persona feedback, and grounds recommendations in uploaded value proposition / research knowledge.

The runtime does **not** load personas, products, risk checks, prompt templates, or report sections from source files. Runtime configuration is read from DynamoDB. The included bootstrap script is only a local demo convenience that writes editable configuration records into DynamoDB.

## What this project implements

- One Evernorth-themed single screen for running usability tests.
- Figma URL intake with Figma API support.
- Screen-reader representation from Figma nodes: layer text, inferred role, reading order, hierarchy.
- Persona selection from DynamoDB.
- Add Persona modal when a needed persona does not exist.
- Upload value proposition / research documents as supplemental knowledge base.
- Configurable risk checklists and prompt templates loaded from DynamoDB.
- Evidence-backed usability report with prioritized findings.
- DynamoDB Local and DynamoDB Admin for local setup.

## Local run

```bash
cp .env.example .env
docker compose up --build
```

In another terminal, create the table and load demo configuration into DynamoDB:

```bash
docker compose exec backend python scripts/create_tables.py
docker compose exec backend python scripts/bootstrap_dev_config.py
```

Open:

- Frontend: http://localhost:5173
- Backend docs: http://localhost:8000/docs
- DynamoDB Admin: http://localhost:8001

## Figma setup

Set this in `.env` if you want live Figma extraction:

```env
FIGMA_ACCESS_TOKEN=your_figma_token
```

The app can still run without Figma token; it will ask for extracted screen text or use uploaded context.

## LiteLLM setup

The backend calls an OpenAI-compatible LiteLLM endpoint.

```env
LITELLM_API_BASE=https://your-litellm-host
LITELLM_API_KEY=your_key
LITELLM_MODEL=gpt-4o-mini
```

If LiteLLM is not configured, the app still stores configs and knowledge but cannot produce AI synthesis.

## DynamoDB single-table design

Default table: `UserXAgentLocal`

Entity patterns:

| Entity | PK | SK |
|---|---|---|
| Product config | `CONFIG#PRODUCT` | `PRODUCT#<id>` |
| Journey config | `CONFIG#JOURNEY#<product_id>` | `JOURNEY#<id>` |
| Persona | `CONFIG#PERSONA` | `PERSONA#<id>` |
| Risk checklist | `CONFIG#RISK_CHECKLIST` | `RISK#<id>` |
| Prompt template | `CONFIG#PROMPT_TEMPLATE` | `PROMPT#<id>` |
| Knowledge source | `KNOWLEDGE#SOURCE` | `SOURCE#<id>` |
| Knowledge chunk | `KNOWLEDGE#<source_id>` | `CHUNK#<n>` |
| Agent run | `RUN#<run_id>` | `METADATA` |
| Run finding | `RUN#<run_id>` | `FINDING#<n>` |

## Important safety note

Use de-identified value proposition and feedback data. Do not upload raw PHI, member identifiers, claim numbers, phone numbers, addresses, or transcripts containing sensitive information unless your internal controls explicitly allow it.
