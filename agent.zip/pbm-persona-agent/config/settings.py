from __future__ import annotations

import os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()


@dataclass(frozen=True)
class Settings:
    app_name: str = os.getenv("APP_NAME", "PBM Persona Agent")
    litellm_api_base: str | None = os.getenv("LITELLM_API_BASE")
    litellm_api_key: str | None = os.getenv("LITELLM_API_KEY")
    litellm_model: str = os.getenv("LITELLM_MODEL", "company-approved-model")

    def litellm_configured(self) -> bool:
        return bool(self.litellm_api_base and self.litellm_api_key)


settings = Settings()
