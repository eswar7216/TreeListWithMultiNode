from agent.persona_agent import PersonaAgentRequest, run_persona_agent


def test_persona_agent_library_only_selects_defaults():
    request = PersonaAgentRequest(
        product_id="savings_advisor",
        journey_id="alternative_medication_recommendation",
        screen_name="Rx Configuration",
        user_flow_context="Member reviews lower-cost medication and pharmacy savings.",
        screen_text="Cost $523.68, with changes $8.06, continue",
        risk_categories=["cost_clarity", "medication_switching"],
        mode="library_only",
    )
    result = run_persona_agent(request, llm=None)
    assert result.selected_personas
    assert result.product_id == "savings_advisor"
    assert any(item["persona"]["persona_id"] == "cost_sensitive_member" for item in result.selected_personas)
