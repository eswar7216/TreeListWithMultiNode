# PBM Persona Agent

A configurable, low-code/no-code Persona Agent for PBM member-facing UX research workflows.

This project is the first module of a broader AI UX Research Agent platform. It selects reusable research personas from JSON configuration, optionally generates missing personas on demand through LiteLLM, and simulates persona-specific usability feedback for prototype screens.

## What it does

- Loads product, journey, persona, and selection-node configuration from `config/persona_nodes.json`
- Selects personas using product defaults, risk categories, and screen context
- Optionally generates additional personas on demand using LiteLLM
- Simulates persona-specific feedback for a screen or prototype text
- Generates recruiting criteria
- Provides a Streamlit UI and CLI runner

## Project structure

```text
pbm-persona-agent/
  agent/
    llm_client.py
    persona_agent.py
    persona_prompts.py
  config/
    settings.py
    persona_nodes.json
  app.py
  persona_cli.py
  pyproject.toml
  requirements.txt
  .env.example
```

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

Update `.env` with your LiteLLM details if you want on-demand generation and simulated feedback.

```bash
streamlit run app.py
```

Or run the CLI:

```bash
python persona_cli.py
```

## Modes

- `library_only`: select personas from JSON config only
- `hybrid`: select from config and generate missing personas through LiteLLM
- `generate_only`: rely mainly on LLM generation, while still using product context

## Guardrails

The agent output is simulated research support. It does not replace moderated usability research, UX researcher judgment, accessibility review, product review, legal/compliance review, or clinical review.
