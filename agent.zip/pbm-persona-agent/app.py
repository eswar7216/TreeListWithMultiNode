from __future__ import annotations

from dataclasses import asdict

import streamlit as st

from agent.llm_client import LiteLLMClient
from agent.persona_agent import PersonaAgentRequest, result_to_markdown, run_persona_agent
from config.settings import settings

DEMO_MODELS = [settings.litellm_model, "gpt-4o", "gpt-4o-mini"]


def render_persona_agent() -> None:
    st.subheader("PBM Persona Agent")
    st.caption(
        "Generate or select research personas from low-code configuration, then simulate persona-specific UX feedback."
    )

    if not settings.litellm_configured():
        st.warning(
            "LiteLLM is not configured. The agent can still select personas from config, "
            "but on-demand generation and simulated feedback require LITELLM_API_KEY."
        )

    persona_model = st.selectbox("Persona Agent model", DEMO_MODELS, index=0, key="persona_model")

    col1, col2 = st.columns([1, 1])

    with col1:
        product_id = st.selectbox(
            "Product",
            options=["savings_advisor", "generic_pbm_product"],
            format_func=lambda x: "Savings Advisor" if x == "savings_advisor" else "Generic PBM Product",
        )

        journey_id = st.selectbox(
            "Journey",
            options=["alternative_medication_recommendation", ""],
            format_func=lambda x: "Alternative Medication Recommendation" if x else "None",
        )

        screen_name = st.text_input("Screen name", value="Rx Configuration")

        user_flow_context = st.text_area(
            "User flow context",
            value=(
                "Member reviews recommended medication, pharmacy, and 3-month supply changes "
                "to lower prescription cost."
            ),
            height=110,
        )

        screen_text = st.text_area(
            "Screen text / detected UI content",
            value=(
                "Recommended changes. Switch to a lower cost alternative. Switch to approved pharmacy. "
                "Switch to 3-month supply. No changes $523.68. With changes $8.06. Continue."
            ),
            height=130,
        )

    with col2:
        risk_categories = st.multiselect(
            "Risk categories",
            options=[
                "cost_clarity",
                "savings_trust",
                "medication_switching",
                "doctor_involvement",
                "next_step_clarity",
                "accessibility",
                "plain_language",
                "coverage_rules",
                "confirmation",
            ],
            default=[
                "cost_clarity",
                "medication_switching",
                "doctor_involvement",
                "next_step_clarity",
            ],
        )

        known_constraints_raw = st.text_area(
            "Known constraints",
            value=(
                "Some changes may require doctor involvement.\n"
                "Member may not finalize medication changes in this flow.\n"
                "Displayed costs may be estimates."
            ),
            height=110,
        )

        mode = st.radio(
            "Persona mode",
            options=["library_only", "hybrid", "generate_only"],
            index=1,
            help=(
                "library_only uses config only. hybrid selects from config and generates missing personas. "
                "generate_only relies mainly on the LLM."
            ),
        )

        max_personas = st.slider("Max personas", min_value=1, max_value=8, value=6)

    if st.button("Run Persona Agent", type="primary"):
        request = PersonaAgentRequest(
            product_id=product_id,
            journey_id=journey_id or None,
            screen_name=screen_name,
            user_flow_context=user_flow_context,
            screen_text=screen_text,
            risk_categories=risk_categories,
            known_constraints=[line.strip() for line in known_constraints_raw.splitlines() if line.strip()],
            mode=mode,
            max_personas=max_personas,
        )

        llm_client = None
        if settings.litellm_configured() and mode != "library_only":
            llm_client = LiteLLMClient(model=persona_model)

        with st.spinner("Persona Agent running..."):
            result = run_persona_agent(request, llm=llm_client)

        st.success("Persona Agent completed")
        markdown = result_to_markdown(result)
        st.markdown(markdown)

        with st.expander("Raw JSON result"):
            st.json(asdict(result))

        with st.expander("Persona Agent trace"):
            st.json(result.trace)

        st.download_button(
            label="Download Persona Report",
            data=markdown,
            file_name=f"persona-agent-{screen_name.lower().replace(' ', '-')}.md",
            mime="text/markdown",
        )


def main() -> None:
    st.set_page_config(page_title=settings.app_name, layout="wide")
    st.title(settings.app_name)
    st.caption("Low-code/no-code PBM UX research persona agent")
    render_persona_agent()


if __name__ == "__main__":
    main()
