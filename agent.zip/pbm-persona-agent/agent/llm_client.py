from __future__ import annotations

import requests
from config.settings import settings


class LiteLLMClient:
    """Small LiteLLM chat-completion client.

    The class intentionally mirrors the simple pattern used by internal demo agents:
    construct the client once, then call `chat_completion(...)` with OpenAI-style messages.
    """

    def __init__(self, model: str | None = None) -> None:
        self.model = model or settings.litellm_model
        self.api_base = settings.litellm_api_base
        self.api_key = settings.litellm_api_key

    def chat_completion(
        self,
        messages: list[dict[str, str]],
        temperature: float = 0.1,
        max_tokens: int = 1600,
    ) -> dict:
        if not self.api_base or not self.api_key:
            raise RuntimeError("LiteLLM is not configured. Set LITELLM_API_BASE and LITELLM_API_KEY.")

        url = self.api_base.rstrip("/") + "/chat/completions"
        response = requests.post(
            url,
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
            },
            json={
                "model": self.model,
                "messages": messages,
                "temperature": temperature,
                "max_tokens": max_tokens,
            },
            timeout=60,
        )
        response.raise_for_status()
        return response.json()
