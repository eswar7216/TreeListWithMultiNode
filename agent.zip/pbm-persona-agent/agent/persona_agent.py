from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any

from agent.llm_client import LiteLLMClient
from agent.persona_prompts import (
    GENERATE_PERSONAS_PROMPT,
    PERSONA_SYSTEM_PROMPT,
    SIMULATE_PERSONA_FEEDBACK_PROMPT,
)

CONFIG_PATH = Path(__file__).resolve().parents[1] / "config" / "persona_nodes.json"


@dataclass
class PersonaAgentRequest:
    product_id: str
    screen_name: str
    user_flow_context: str
    journey_id: str | None = None
    screen_text: str = ""
    risk_categories: list[str] = field(default_factory=list)
    known_constraints: list[str] = field(default_factory=list)
    mode: str = "hybrid"  # library_only | generate_only | hybrid
    max_personas: int = 6


@dataclass
class SelectedPersona:
    persona: dict[str, Any]
    why_selected: str
    matched_nodes: list[str] = field(default_factory=list)
    matched_terms: list[str] = field(default_factory=list)


@dataclass
class PersonaAgentResult:
    product_id: str
    screen_name: str
    selected_personas: list[dict[str, Any]]
    generated_personas: list[dict[str, Any]]
    persona_feedback: list[dict[str, Any]]
    recommended_recruiting_criteria: list[str]
    trace: list[dict[str, Any]]
    disclaimer: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _load_config() -> dict[str, Any]:
    with CONFIG_PATH.open("r", encoding="utf-8") as f:
        return json.load(f)


def _safe_json_loads(raw: str) -> dict[str, Any]:
    text = raw.strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.startswith("json"):
            text = text[4:].strip()

    start = text.find("{")
    end = text.rfind("}")
    if start >= 0 and end >= 0:
        text = text[start : end + 1]

    return json.loads(text)


def _normalize(value: str) -> str:
    return value.lower().strip()


def _contains_any_keyword(text: str, keywords: list[str]) -> list[str]:
    normalized_text = _normalize(text)
    return [keyword for keyword in keywords if _normalize(keyword) in normalized_text]


def _find_product(config: dict[str, Any], product_id: str) -> dict[str, Any]:
    for product in config.get("products", []):
        if product.get("product_id") == product_id:
            return product
    raise ValueError(f"Unknown product_id: {product_id}")


def _find_journey(product: dict[str, Any], journey_id: str | None) -> dict[str, Any] | None:
    if not journey_id:
        return None
    for journey in product.get("journeys", []):
        if journey.get("journey_id") == journey_id:
            return journey
    return None


def _persona_by_id(config: dict[str, Any], persona_id: str) -> dict[str, Any] | None:
    for persona in config.get("personas", []):
        if persona.get("persona_id") == persona_id:
            return persona
    return None


def _unique_list(values: list[str]) -> list[str]:
    seen: set[str] = set()
    output: list[str] = []
    for value in values:
        if value not in seen:
            seen.add(value)
            output.append(value)
    return output


def _select_personas_from_config(
    request: PersonaAgentRequest,
    config: dict[str, Any],
    product: dict[str, Any],
    journey: dict[str, Any] | None,
    trace: list[dict[str, Any]],
) -> list[SelectedPersona]:
    selected: dict[str, SelectedPersona] = {}
    product_default_personas = product.get("default_persona_ids", [])
    product_default_risks = product.get("default_risk_categories", [])
    journey_risks = journey.get("risk_categories", []) if journey else []

    all_risk_categories = _unique_list(product_default_risks + journey_risks + request.risk_categories)
    context_text = " ".join(
        [
            request.screen_name,
            request.user_flow_context,
            request.screen_text,
            " ".join(request.known_constraints),
            " ".join(all_risk_categories),
        ]
    )

    if request.mode != "generate_only":
        for persona_id in product_default_personas:
            persona = _persona_by_id(config, persona_id)
            if not persona:
                continue
            selected[persona_id] = SelectedPersona(
                persona=persona,
                why_selected="Included as a default persona for this product configuration.",
                matched_nodes=["product_default"],
                matched_terms=[],
            )

        for node in config.get("selection_nodes", []):
            matched_risks = [
                risk for risk in node.get("match_any_risk_categories", []) if risk in all_risk_categories
            ]
            matched_keywords = _contains_any_keyword(context_text, node.get("match_any_keywords", []))
            matched_terms = _unique_list(matched_risks + matched_keywords)
            if not matched_terms:
                continue

            for persona_id in node.get("include_persona_ids", []):
                persona = _persona_by_id(config, persona_id)
                if not persona:
                    continue

                node_id = node.get("node_id", "unknown_node")
                if persona_id in selected:
                    existing = selected[persona_id]
                    existing.matched_nodes = _unique_list(existing.matched_nodes + [node_id])
                    existing.matched_terms = _unique_list(existing.matched_terms + matched_terms)
                    existing.why_selected = (
                        "Selected because product defaults and configured selection nodes indicate this persona is relevant."
                    )
                else:
                    selected[persona_id] = SelectedPersona(
                        persona=persona,
                        why_selected="Selected because configured selection nodes indicate this persona is relevant.",
                        matched_nodes=[node_id],
                        matched_terms=matched_terms,
                    )

                trace.append(
                    {
                        "kind": "persona_selection_node",
                        "node_id": node_id,
                        "persona_id": persona_id,
                        "matched_terms": matched_terms,
                    }
                )

    max_total = int(config.get("generation_policy", {}).get("max_total_personas", 6))
    return list(selected.values())[: min(request.max_personas, max_total)]


def _extract_llm_content(response: dict[str, Any]) -> str:
    try:
        return response["choices"][0]["message"]["content"]
    except Exception as exc:
        raise RuntimeError(f"Unable to extract LLM response content: {exc}") from exc


def _call_llm_json(llm: LiteLLMClient, prompt: str, max_tokens: int = 1600) -> dict[str, Any]:
    response = llm.chat_completion(
        messages=[
            {"role": "system", "content": PERSONA_SYSTEM_PROMPT},
            {"role": "user", "content": prompt},
        ],
        temperature=0.1,
        max_tokens=max_tokens,
    )
    return _safe_json_loads(_extract_llm_content(response))


def _generate_personas_on_demand(
    request: PersonaAgentRequest,
    config: dict[str, Any],
    product: dict[str, Any],
    journey: dict[str, Any] | None,
    selected_personas: list[SelectedPersona],
    llm: LiteLLMClient,
    trace: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    if request.mode == "library_only":
        return []

    policy = config.get("generation_policy", {})
    if not policy.get("allow_on_demand_generation", True):
        return []

    max_generated = int(policy.get("max_generated_personas", 3))
    product_context = {**product, "selected_journey": journey}

    prompt = GENERATE_PERSONAS_PROMPT.format(
        product_config=json.dumps(product_context, indent=2),
        screen_name=request.screen_name,
        user_flow_context=request.user_flow_context,
        screen_text=request.screen_text or "Not provided",
        risk_categories=json.dumps(request.risk_categories, indent=2),
        selected_personas=json.dumps([item.persona for item in selected_personas], indent=2),
        max_generated_personas=max_generated,
    )

    try:
        result = _call_llm_json(llm, prompt, max_tokens=1800)
        generated = result.get("generated_personas", [])[:max_generated]
        trace.append({"kind": "on_demand_persona_generation", "count": len(generated)})
        return generated
    except Exception as exc:
        trace.append({"kind": "on_demand_persona_generation_error", "error": str(exc)})
        return []


def _simulate_persona_feedback(
    request: PersonaAgentRequest,
    product: dict[str, Any],
    journey: dict[str, Any] | None,
    selected_personas: list[SelectedPersona],
    generated_personas: list[dict[str, Any]],
    llm: LiteLLMClient,
    trace: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    personas = [item.persona for item in selected_personas] + generated_personas
    if not personas:
        return []

    product_context = {**product, "selected_journey": journey}
    prompt = SIMULATE_PERSONA_FEEDBACK_PROMPT.format(
        product_config=json.dumps(product_context, indent=2),
        screen_name=request.screen_name,
        user_flow_context=request.user_flow_context,
        screen_text=request.screen_text or "Not provided",
        known_constraints=json.dumps(request.known_constraints, indent=2),
        personas=json.dumps(personas, indent=2),
    )

    try:
        result = _call_llm_json(llm, prompt, max_tokens=2500)
        feedback = result.get("persona_feedback", [])
        trace.append({"kind": "persona_feedback_simulation", "count": len(feedback)})
        return feedback
    except Exception as exc:
        trace.append({"kind": "persona_feedback_simulation_error", "error": str(exc)})
        return []


def _build_recruiting_criteria(
    selected_personas: list[SelectedPersona], generated_personas: list[dict[str, Any]]
) -> list[str]:
    criteria = {
        "Participants should have active health insurance.",
        "Participants should currently take or manage at least one prescription medication.",
    }
    persona_text = json.dumps([item.persona for item in selected_personas] + generated_personas).lower()

    if "cost" in persona_text or "savings" in persona_text:
        criteria.add("Include participants who are sensitive to prescription cost.")
    if "caregiver" in persona_text:
        criteria.add("Include participants who manage prescriptions for someone else.")
    if "switch" in persona_text or "alternative" in persona_text:
        criteria.add("Include a mix of participants with and without prior medication-switching experience.")
    if "senior" in persona_text or "low_digital_confidence" in persona_text:
        criteria.add("Include older adults or participants with lower digital confidence.")
    if "health_literacy" in persona_text or "plain_language" in persona_text:
        criteria.add("Include participants who may be unfamiliar with PBM or benefit terminology.")

    return sorted(criteria)


def run_persona_agent(
    request: PersonaAgentRequest,
    llm: LiteLLMClient | None = None,
) -> PersonaAgentResult:
    trace: list[dict[str, Any]] = []
    config = _load_config()
    product = _find_product(config, request.product_id)
    journey = _find_journey(product, request.journey_id)

    trace.append({"kind": "config_loaded", "product_id": request.product_id, "journey_id": request.journey_id})

    selected = _select_personas_from_config(request, config, product, journey, trace)
    generated: list[dict[str, Any]] = []
    feedback: list[dict[str, Any]] = []

    if llm and request.mode in ("hybrid", "generate_only"):
        generated = _generate_personas_on_demand(request, config, product, journey, selected, llm, trace)
        feedback = _simulate_persona_feedback(request, product, journey, selected, generated, llm, trace)
    else:
        trace.append({"kind": "llm_skipped", "reason": "LLM client not provided or mode is library_only."})

    return PersonaAgentResult(
        product_id=request.product_id,
        screen_name=request.screen_name,
        selected_personas=[
            {
                "persona": item.persona,
                "why_selected": item.why_selected,
                "matched_nodes": item.matched_nodes,
                "matched_terms": item.matched_terms,
            }
            for item in selected
        ],
        generated_personas=generated,
        persona_feedback=feedback,
        recommended_recruiting_criteria=_build_recruiting_criteria(selected, generated),
        trace=trace,
        disclaimer=(
            "This is AI-generated simulated persona feedback. It complements but does not replace "
            "moderated user research, UX researcher judgment, accessibility review, product review, "
            "legal/compliance review, or clinical review."
        ),
    )


def result_to_markdown(result: PersonaAgentResult) -> str:
    lines: list[str] = []
    lines.append(f"# Persona Agent Result — {result.screen_name}")
    lines.append("")
    lines.append(result.disclaimer)
    lines.append("")

    lines.append("## Selected Personas")
    for item in result.selected_personas:
        persona = item["persona"]
        lines.append(f"### {persona.get('name')}")
        lines.append(persona.get("description", ""))
        lines.append("")
        lines.append(f"**Why selected:** {item.get('why_selected')}")
        if item.get("matched_terms"):
            lines.append(f"**Matched terms:** {', '.join(item['matched_terms'])}")
        lines.append("")
        lines.append("**Likely questions:**")
        for question in persona.get("likely_questions", []):
            lines.append(f"- {question}")
        lines.append("")
        lines.append("**Likely friction points:**")
        for friction in persona.get("likely_friction_points", []):
            lines.append(f"- {friction}")
        lines.append("")

    if result.generated_personas:
        lines.append("## Generated Personas")
        for persona in result.generated_personas:
            lines.append(f"### {persona.get('name')}")
            lines.append(persona.get("description", ""))
            lines.append(f"**Why generated:** {persona.get('why_generated', '')}")
            lines.append("")

    if result.persona_feedback:
        lines.append("## Simulated Persona Feedback")
        for feedback in result.persona_feedback:
            lines.append(f"### {feedback.get('persona_name')}")
            lines.append(f"**Severity:** {feedback.get('severity')}")
            lines.append("")
            lines.append(feedback.get("likely_reaction", ""))
            lines.append("")
            lines.append("**Likely questions:**")
            for question in feedback.get("likely_questions", []):
                lines.append(f"- {question}")
            lines.append("")
            lines.append("**Friction points:**")
            for friction in feedback.get("likely_friction_points", []):
                lines.append(f"- {friction}")
            lines.append("")
            lines.append("**PBM-specific concerns:**")
            for concern in feedback.get("pbm_specific_concerns", []):
                lines.append(f"- {concern}")
            lines.append("")
            lines.append("**Design implications:**")
            for implication in feedback.get("design_implications", []):
                lines.append(f"- {implication}")
            lines.append("")

    lines.append("## Recommended Recruiting Criteria")
    for criterion in result.recommended_recruiting_criteria:
        lines.append(f"- {criterion}")
    return "\n".join(lines)
