from __future__ import annotations

from agent.llm_client import LiteLLMClient
from agent.persona_agent import PersonaAgentRequest, result_to_markdown, run_persona_agent
from config.settings import settings


def main() -> None:
    request = PersonaAgentRequest(
        product_id="savings_advisor",
        journey_id="alternative_medication_recommendation",
        screen_name="Rx Configuration",
        user_flow_context=(
            "Member reviews recommended medication, pharmacy, and 3-month supply changes "
            "to lower prescription cost."
        ),
        screen_text=(
            "Recommended changes. Switch to a lower cost alternative. Switch to approved pharmacy. "
            "Switch to 3-month supply. No changes $523.68. With changes $8.06. Continue."
        ),
        risk_categories=[
            "cost_clarity",
            "medication_switching",
            "doctor_involvement",
            "next_step_clarity",
        ],
        known_constraints=[
            "Some changes may require doctor involvement.",
            "Member may not finalize medication changes in this flow.",
            "Displayed costs may be estimates.",
        ],
        mode="hybrid" if settings.litellm_configured() else "library_only",
        max_personas=6,
    )

    llm = LiteLLMClient() if settings.litellm_configured() else None
    result = run_persona_agent(request, llm=llm)
    print(result_to_markdown(result))


if __name__ == "__main__":
    main()
